package com.example.overlay

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val bg = Color(0xFF0B0F17)
    val surface = Color(0xFF131A26)
    val card = Color(0xFF1A2333)
    val line = Color(0xFF263148)
    val text = Color(0xFFE6EBF5)
    val sub = Color(0xFF8A96AD)
    val blue = Color(0xFF4C8DFF)
    val green = Color(0xFF2EBD85)
    val red = Color(0xFFF6465D)
    val amber = Color(0xFFF0B90B)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.blue,
            onPrimary = Color.White,
            background = C.bg,
            onBackground = C.text,
            surface = C.surface,
            onSurface = C.text,
            surfaceVariant = C.card,
            onSurfaceVariant = C.sub,
            error = C.red,
            outline = C.line
        ),
        content = content
    )
}
