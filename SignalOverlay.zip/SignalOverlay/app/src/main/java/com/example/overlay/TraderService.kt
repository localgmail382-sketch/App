package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Keeps the engine + WebView alive in the background (screen off / app closed). */
class TraderService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            getSystemService(NotificationManager::class.java).notify(1, build())
            h.postDelayed(this, 5000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        WebHolder.ensure(applicationContext)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("ov", "Signal Pro", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun build(): Notification {
        val text = when {
            Ui.running && Ui.statusText == "Trading" -> "Trade in progress - stake " + money(Ui.nextStake)
            Ui.running && Ui.nextText.isNotEmpty() ->
                "Next " + Ui.nextText + " - stake " + money(Ui.nextStake) + (if (Ui.step > 0) " (MTG" + Ui.step + ")" else "")
            else -> Ui.statusText
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "ov")
            .setContentTitle("Signal Pro - " + Ui.wins + "W / " + Ui.losses + "L")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(this, 1, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (wl == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ov:trader")
            wl?.acquire(8 * 60 * 60 * 1000L)
        }
        h.removeCallbacks(tick)
        h.postDelayed(tick, 5000)

        // new list from the app, or (after the system restarted us) the saved one
        val prefs = getSharedPreferences("ov", 0)
        val text = intent?.getStringExtra("text") ?: prefs.getString("signals", "") ?: ""
        if (text.isNotBlank()) WebHolder.engine.start(text)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        val done = Ui.statusText == "Finished" || Ui.statusText == "Loss limit hit"
        WebHolder.engine.stop(if (done) Ui.statusText else "Stopped")
        if (wl?.isHeld == true) wl?.release()
        super.onDestroy()
    }
}
