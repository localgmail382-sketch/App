package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Keeps the engine + WebView alive in the background (screen off / app closed). */
class TraderService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            getSystemService(NotificationManager::class.java).notify(1, build())
            h.postDelayed(this, 5000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        WebHolder.ensure(applicationContext)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("ov", "Signal Pro", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun build(): Notification {
        val text = when {
            Ui.running && Ui.statusText == "Trading" -> "Trade in progress - stake " + money(Ui.nextStake)
            Ui.running && Ui.nextText.isNotEmpty() ->
                "Next " + Ui.nextText + " - stake " + money(Ui.nextStake) + (if (Ui.step > 0) " (MTG" + Ui.step + ")" else "")
            else -> Ui.statusText
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "ov")
            .setContentTitle("Signal Pro - " + Ui.wins + "W / " + Ui.losses + "L")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(this, 1, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (wl == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ov:trader")
            wl?.acquire(8 * 60 * 60 * 1000L)
        }
        h.removeCallbacks(tick)
        h.postDelayed(tick, 5000)

        val fromApp = intent?.getStringExtra("text")
        if (fromApp != null) {
            // started from the app: the pre-flight check was already shown to the user
            if (fromApp.isNotBlank()) WebHolder.engine.start(fromApp)
        } else {
            // restarted by Android: only resume once the broker page is ready and the checks pass
            val saved = getSharedPreferences("ov", 0).getString("signals", "") ?: ""
            if (saved.isNotBlank()) resumeWhenReady(saved, 0) else stopSelf()
        }
        return START_STICKY
    }

    private fun resumeWhenReady(text: String, tries: Int) {
        if (!WebHolder.pageReady) {
            if (tries > 60) {
                WebHolder.log("restart: broker page never became ready - not resuming")
                stopSelf()
                return
            }
            h.postDelayed({ resumeWhenReady(text, tries + 1) }, 1000)
            return
        }
        WebHolder.engine.preview(text)
        WebHolder.engine.preflight { list ->
            val failed = list.firstOrNull { !it.ok }
            if (failed == null) {
                WebHolder.engine.start(text)
                WebHolder.log("resumed after restart")
            } else {
                WebHolder.log("restart: pre-flight failed (" + failed.label + ") - not resuming")
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        val done = Ui.statusText == "Finished" || Ui.statusText == "Loss limit hit"
        WebHolder.engine.stop(if (done) Ui.statusText else "Stopped")
        if (wl?.isHeld == true) wl?.release()
        super.onDestroy()
    }
}
