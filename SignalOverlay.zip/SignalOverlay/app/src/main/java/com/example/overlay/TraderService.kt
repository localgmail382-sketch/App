package com.example.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Keeps the engine + WebView alive in the background (screen off / app closed). */
class TraderService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        WebHolder.ensure(applicationContext)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("ov", "Signal trader", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = NotificationCompat.Builder(this, "ov")
            .setContentTitle("Signal trader running")
            .setContentText("Trading queued signals")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (wl == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ov:trader")
            wl?.acquire(8 * 60 * 60 * 1000L)
        }

        // new list from the app, or (after the system restarted us) the saved one
        val prefs = getSharedPreferences("ov", 0)
        val text = intent?.getStringExtra("text") ?: prefs.getString("signals", "") ?: ""
        if (text.isNotBlank()) WebHolder.engine.start(text)
        return START_STICKY
    }

    override fun onDestroy() {
        WebHolder.engine.stop()
        if (wl?.isHeld == true) wl?.release()
        super.onDestroy()
    }
}
