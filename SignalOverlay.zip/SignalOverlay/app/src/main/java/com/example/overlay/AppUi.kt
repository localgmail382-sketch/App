package com.example.overlay

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlinx.coroutines.delay

// ============================================================ root

@Composable
fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var showChecks by remember { mutableStateOf(false) }
    var pendingStart by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun startNow() {
        val prefs = ctx.getSharedPreferences("ov", 0)
        prefs.edit().putString("signals", Ui.signalText).putString("draft", Ui.signalText).apply()
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, TraderService::class.java).putExtra("text", Ui.signalText)
        )
    }

    fun stopNow() {
        ctx.getSharedPreferences("ov", 0).edit().remove("signals").apply()
        WebHolder.engine.stop()
        ctx.stopService(Intent(ctx, TraderService::class.java))
        WebHolder.log("stopped")
    }

    fun runChecks(thenStart: Boolean) {
        Ui.checking = true
        WebHolder.engine.preflight { list ->
            Ui.checks.clear()
            Ui.checks.addAll(list)
            Ui.checking = false
            if (thenStart && list.all { it.ok }) {
                startNow()
            } else {
                pendingStart = thenStart
                showChecks = true
            }
        }
    }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            WebArea(Modifier.fillMaxSize())
            if (tab != 0) {
                Surface(Modifier.fillMaxSize(), color = C.bg) {
                    when (tab) {
                        1 -> SignalsTab()
                        2 -> HistoryTab()
                        else -> SettingsTab()
                    }
                }
            }
        }
        ControlBar(
            onChecks = { runChecks(false) },
            onStartStop = {
                if (Ui.running) {
                    stopNow()
                } else if (Ui.signalText.isBlank()) {
                    Toast.makeText(ctx, "Paste your signals first", Toast.LENGTH_SHORT).show()
                    tab = 1
                } else {
                    runChecks(true)
                }
            }
        )
        NavBar(tab) { tab = it }
    }

    if (showChecks) {
        AlertDialog(
            onDismissRequest = { showChecks = false; pendingStart = false },
            containerColor = C.surface,
            title = { Text("Pre-flight check") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Ui.checks.forEach { CheckRow(it) }
                }
            },
            confirmButton = {
                if (pendingStart) {
                    TextButton(onClick = { showChecks = false; pendingStart = false; startNow() }) {
                        Text("Start anyway", color = C.amber)
                    }
                } else {
                    TextButton(onClick = { showChecks = false }) { Text("Close") }
                }
            },
            dismissButton = {
                if (pendingStart) {
                    TextButton(onClick = { showChecks = false; pendingStart = false }) { Text("Cancel") }
                }
            }
        )
    }
}

// ============================================================ shared pieces

@Composable
fun WebArea(modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            val fl = FrameLayout(c)
            (WebHolder.web.parent as? ViewGroup)?.removeView(WebHolder.web)
            fl.addView(
                WebHolder.web,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            fl
        },
        onRelease = { it.removeAllViews() }
    )
}

@Composable
fun Pill(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun Stat(label: String, value: String, color: Color = C.text) {
    Column {
        Text(label, color = C.sub, fontSize = 10.sp)
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Header() {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }
    val trading = Ui.running && Ui.statusText == "Trading"
    val dot = when {
        trading -> C.amber
        Ui.running -> C.green
        Ui.statusText == "Loss limit hit" -> C.red
        else -> C.sub
    }
    val label = when {
        trading -> "TRADING"
        Ui.running -> "WAITING"
        else -> Ui.statusText.uppercase()
    }
    val left = if (Ui.running && Ui.nextAt > 0) maxOf(0L, (Ui.nextAt - now) / 1000) else -1L
    val mm = left / 60
    val ss = left % 60
    val secText = if (ss < 10) "0$ss" else "$ss"
    val nextLine = if (left >= 0) "Next ${Ui.nextText}  -  $mm:$secText" else "No signal queued"
    val pnlColor = if (Ui.pnl > 0) C.green else if (Ui.pnl < 0) C.red else C.text
    val pnlText = (if (Ui.pnl < 0) "-" else if (Ui.pnl > 0) "+" else "") + "$" + money(abs(Ui.pnl))
    val stakeText = "$" + money(Ui.nextStake) + (if (Ui.step > 0) "  MTG" + Ui.step else "")
    val balText = Ui.balance?.let { "$" + money(it) } ?: "-"

    Column(Modifier.fillMaxWidth().background(C.surface).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = dot)
            Spacer(Modifier.weight(1f))
            Text(nextLine, color = C.sub, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("STAKE", stakeText)
            Stat("WIN / LOSS", "${Ui.wins} / ${Ui.losses}")
            Stat("P&L", pnlText, pnlColor)
            Stat("BALANCE", balText)
        }
    }
}

@Composable
fun ControlBar(onChecks: () -> Unit, onStartStop: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.surface).padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(onClick = onChecks, modifier = Modifier.weight(1f)) {
            Text(if (Ui.checking) "Checking..." else "Pre-flight check")
        }
        Button(
            onClick = onStartStop,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = if (Ui.running) C.red else C.green)
        ) {
            Text(if (Ui.running) "STOP" else "START", fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val tabs = listOf(
        "Trade" to Icons.Filled.Home,
        "Signals" to Icons.Filled.Menu,
        "History" to Icons.Filled.DateRange,
        "Settings" to Icons.Filled.Settings
    )
    NavigationBar(containerColor = C.surface) {
        tabs.forEachIndexed { i, pair ->
            NavigationBarItem(
                selected = tab == i,
                onClick = { onTab(i) },
                icon = { Icon(pair.second, contentDescription = pair.first) },
                label = { Text(pair.first) }
            )
        }
    }
}

@Composable
fun CheckRow(c: PreCheck) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (c.ok) Icons.Filled.Check else Icons.Filled.Close,
            contentDescription = null,
            tint = if (c.ok) C.green else C.red,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(c.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(c.detail, color = C.sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun DirBadge(dir: String) {
    Pill(dir.uppercase(), if (dir == "call") C.green else C.red)
}

// ============================================================ signals tab

@Composable
fun SignalsTab() {
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = Ui.signalText,
            onValueChange = { Ui.signalText = it },
            modifier = Modifier.fillMaxWidth().height(130.dp),
            label = { Text("Paste signals, one per line") },
            placeholder = { Text("16:42 AUDCAD_otc CALL 60") },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { Ui.listInfo = WebHolder.engine.preview(Ui.signalText) }) { Text("Load list") }
            TextButton(onClick = { Ui.signalText = ""; Ui.cards.clear(); Ui.listInfo = "" }) { Text("Clear") }
            Text(Ui.listInfo, color = C.sub, fontSize = 12.sp)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(Ui.cards, key = { it.id }) { SignalCard(it) }
        }
    }
}

@Composable
fun SignalCard(c: SigItem) {
    val col: Color
    val label: String
    when (c.status) {
        "won" -> { col = C.green; label = "WON" }
        "lost" -> { col = C.red; label = "LOST" }
        "draw" -> { col = C.amber; label = "DRAW" }
        "live" -> { col = C.blue; label = "LIVE" }
        "waiting" -> { col = C.blue; label = "WAITING" }
        "skipped" -> { col = C.sub; label = "SKIPPED" }
        else -> { col = C.sub; label = "PENDING" }
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(C.card).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(c.timeLabel, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(prettyAsset(c.asset), fontSize = 14.sp)
            if (c.note.isNotEmpty()) Text(c.note, color = C.sub, fontSize = 12.sp)
        }
        DirBadge(c.dir)
        Spacer(Modifier.width(8.dp))
        Pill(label, col)
    }
}

// ============================================================ history tab

@Composable
fun HistoryTab() {
    val total = Ui.wins + Ui.losses
    val rate = if (total > 0) (Ui.wins * 100) / total else 0
    val pnlColor = if (Ui.pnl > 0) C.green else if (Ui.pnl < 0) C.red else C.text
    val pnlText = (if (Ui.pnl < 0) "-" else if (Ui.pnl > 0) "+" else "") + "$" + money(abs(Ui.pnl))
    val rows = Ui.history.reversed()

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.card).padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Stat("TRADES", total.toString())
            Stat("WINS", Ui.wins.toString(), C.green)
            Stat("LOSSES", Ui.losses.toString(), C.red)
            Stat("WIN RATE", "$rate%")
            Stat("P&L", pnlText, pnlColor)
        }
        TextButton(onClick = {
            Ui.history.clear(); Ui.wins = 0; Ui.losses = 0; Ui.pnl = 0.0
        }) { Text("Reset statistics") }
        if (rows.isEmpty()) {
            Text("No trades yet.", color = C.sub)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(rows) { HistoryRow(it) }
        }
    }
}

@Composable
fun HistoryRow(h: HistoryItem) {
    val col = when (h.result) {
        "WIN" -> C.green
        "LOSS" -> C.red
        else -> C.amber
    }
    val pnl = (if (h.pnl < 0) "-" else if (h.pnl > 0) "+" else "") + "$" + money(abs(h.pnl))
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(C.card).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(h.time + "  " + prettyAsset(h.asset), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Stake $" + money(h.stake) + (if (h.step > 0) "  MTG" + h.step else ""),
                color = C.sub, fontSize = 12.sp
            )
        }
        DirBadge(h.dir)
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill(h.result, col)
            Text(pnl, color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ============================================================ settings tab

@Composable
fun NumField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        singleLine = true,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = C.blue, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun SettingsTab() {
    val ctx = LocalContext.current
    val cfg = WebHolder.cfg
    val prefs = remember { ctx.getSharedPreferences("ov", 0) }
    var stake by remember { mutableStateOf(cfg.baseStake.toString()) }
    var mult by remember { mutableStateOf(cfg.multiplier.toString()) }
    var steps by remember { mutableStateOf(cfg.maxSteps.toString()) }
    var loss by remember { mutableStateOf(cfg.dailyLossLimit.toString()) }
    var real by remember { mutableStateOf(cfg.allowReal) }
    var confirmReal by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    val b = stake.toDoubleOrNull() ?: 1.0
    val m = mult.toDoubleOrNull() ?: 2.0
    val n = steps.toIntOrNull() ?: 2
    var chain = ""
    var worst = 0.0
    for (i in 0..n) {
        val v = b * Math.pow(m, i.toDouble())
        worst += v
        chain += (if (i > 0) " > " else "") + "$" + money(v)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SectionTitle("MONEY MANAGEMENT")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("Base stake", stake, { stake = it; saved = false }, Modifier.weight(1f))
            NumField("Multiplier", mult, { mult = it; saved = false }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField("MTG steps", steps, { steps = it; saved = false }, Modifier.weight(1f))
            NumField("Daily loss stop", loss, { loss = it; saved = false }, Modifier.weight(1f))
        }
        Text("Chain: $chain", color = C.sub, fontSize = 13.sp)
        Text("Worst case in one chain: $" + money(worst), color = C.amber, fontSize = 13.sp)
        Button(onClick = {
            cfg.baseStake = b
            cfg.multiplier = m
            cfg.maxSteps = n
            cfg.dailyLossLimit = loss.toDoubleOrNull() ?: 30.0
            cfg.save(prefs)
            WebHolder.engine.refreshStake()
            saved = true
        }) { Text(if (saved) "Saved" else "Save settings") }

        SectionTitle("ACCOUNT")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Allow REAL account trading")
                Text(if (real) "Real money can be traded" else "Demo only (recommended)", color = C.sub, fontSize = 12.sp)
            }
            Switch(checked = real, onCheckedChange = {
                if (it) {
                    confirmReal = true
                } else {
                    real = false
                    cfg.allowReal = false
                    cfg.save(prefs)
                }
            })
        }

        SectionTitle("TOOLS")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                WebHolder.web.loadUrl(WebHolder.DEFAULT_URL)
            }, modifier = Modifier.weight(1f)) { Text("Reload page") }
            OutlinedButton(onClick = {
                WebHolder.web.evaluateJavascript("window.__ov ? window.__ov.scan() : 'page not ready'", null)
            }, modifier = Modifier.weight(1f)) { Text("Scan page") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                )
            }, modifier = Modifier.weight(1f)) { Text("Allow background") }
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("log", Ui.logLines.joinToString("\n")))
                Toast.makeText(ctx, "Log copied", Toast.LENGTH_SHORT).show()
            }, modifier = Modifier.weight(1f)) { Text("Copy log") }
        }

        SectionTitle("ACTIVITY LOG")
        val lines = Ui.logLines.takeLast(80).reversed()
        Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(12.dp)).background(C.card).padding(8.dp)) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(lines) {
                    Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = C.sub)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (confirmReal) {
        AlertDialog(
            onDismissRequest = { confirmReal = false },
            containerColor = C.surface,
            title = { Text("Enable REAL account trading?") },
            text = { Text("Trades will use real money. Losses are real, and martingale increases the risk with every step. Test on demo first.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReal = false
                    real = true
                    cfg.allowReal = true
                    cfg.save(prefs)
                }) { Text("Enable", color = C.red) }
            },
            dismissButton = { TextButton(onClick = { confirmReal = false }) { Text("Cancel") } }
        )
    }
}
