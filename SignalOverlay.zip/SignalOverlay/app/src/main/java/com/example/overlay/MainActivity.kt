package com.example.overlay

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var logView: TextView
    private val risk = Risk()
    private lateinit var trader: SignalTrader

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        logView = findViewById(R.id.logView)
        val urlBox = findViewById<EditText>(R.id.urlBox)
        val signalBox = findViewById<EditText>(R.id.signalBox)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(risk) { log(it) }, "AppModule")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(OVERLAY_JS, null)
            }
        }
        trader = SignalTrader(web, risk) { log(it) }

        findViewById<Button>(R.id.goBtn).setOnClickListener {
            var u = urlBox.text.toString().trim()
            if (u.isNotEmpty()) {
                if (!u.startsWith("http")) u = "https://$u"
                web.loadUrl(u)
            }
        }
        findViewById<Button>(R.id.startBtn).setOnClickListener {
            val n = trader.load(signalBox.text.toString())
            log("loaded $n signal(s)")
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            trader.stop(); log("stopped")
        }
        findViewById<Switch>(R.id.realSwitch).setOnCheckedChangeListener { _, on ->
            risk.allowReal = on; log(if (on) "REAL allowed" else "demo only")
        }
    }

    private fun log(msg: String) = runOnUiThread {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logView.append("$t $msg\n")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
