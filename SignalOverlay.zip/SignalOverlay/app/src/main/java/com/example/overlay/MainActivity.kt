package com.example.overlay

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebHolder.ensure(applicationContext)
        val prefs = getSharedPreferences("ov", 0)
        if (Ui.signalText.isEmpty()) Ui.signalText = prefs.getString("draft", "") ?: ""
        if (Ui.signalText.isNotBlank() && !Ui.running) Ui.listInfo = WebHolder.engine.preview(Ui.signalText)
        setContent { AppTheme { App() } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (WebHolder.web.canGoBack()) WebHolder.web.goBack() else moveTaskToBack(true)
            }
        })
    }

    override fun onPause() {
        getSharedPreferences("ov", 0).edit().putString("draft", Ui.signalText).apply()
        super.onPause()
    }
}
