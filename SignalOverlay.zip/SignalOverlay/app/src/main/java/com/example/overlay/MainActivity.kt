package com.example.overlay

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var container: FrameLayout
    private lateinit var logView: TextView

    @SuppressLint("BatteryLife")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        WebHolder.ensure(applicationContext)
        val prefs = getSharedPreferences("ov", 0)

        container = findViewById(R.id.webContainer)
        logView = findViewById(R.id.logView)
        val urlBox = findViewById<EditText>(R.id.urlBox)
        val signalBox = findViewById<EditText>(R.id.signalBox)
        val stakeBox = findViewById<EditText>(R.id.stakeBox)
        val multBox = findViewById<EditText>(R.id.multBox)
        val stepsBox = findViewById<EditText>(R.id.stepsBox)
        val lossBox = findViewById<EditText>(R.id.lossBox)
        val realSwitch = findViewById<Switch>(R.id.realSwitch)

        // attach the long-lived WebView
        (WebHolder.web.parent as? ViewGroup)?.removeView(WebHolder.web)
        container.addView(
            WebHolder.web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        // restore saved values
        val cfg = WebHolder.cfg
        urlBox.setText(prefs.getString("url", null) ?: WebHolder.DEFAULT_URL)
        signalBox.setText(prefs.getString("signals", ""))
        stakeBox.setText(cfg.baseStake.toString())
        multBox.setText(cfg.multiplier.toString())
        stepsBox.setText(cfg.maxSteps.toString())
        lossBox.setText(cfg.dailyLossLimit.toString())
        realSwitch.isChecked = cfg.allowReal

        logView.text = WebHolder.logBuf.toString()
        WebHolder.logListener = { line -> logView.append(line + "\n") }

        findViewById<Button>(R.id.goBtn).setOnClickListener {
            var u = urlBox.text.toString().trim()
            if (u.isNotEmpty()) {
                if (!u.startsWith("http")) u = "https://$u"
                prefs.edit().putString("url", u).apply()
                WebHolder.web.loadUrl(u)
            }
        }

        realSwitch.setOnCheckedChangeListener { _, on ->
            cfg.allowReal = on
            cfg.save(prefs)
            WebHolder.log(if (on) "REAL account trading ALLOWED" else "demo only")
        }

        findViewById<Button>(R.id.startBtn).setOnClickListener {
            cfg.baseStake = stakeBox.text.toString().toDoubleOrNull() ?: 1.0
            cfg.multiplier = multBox.text.toString().toDoubleOrNull() ?: 2.0
            cfg.maxSteps = stepsBox.text.toString().toIntOrNull() ?: 2
            cfg.dailyLossLimit = lossBox.text.toString().toDoubleOrNull() ?: 30.0
            cfg.save(prefs)
            val text = signalBox.text.toString()
            prefs.edit().putString("signals", text).apply()
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            ContextCompat.startForegroundService(
                this, Intent(this, TraderService::class.java).putExtra("text", text)
            )
        }

        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            prefs.edit().remove("signals").apply()
            WebHolder.engine.stop()
            stopService(Intent(this, TraderService::class.java))
            WebHolder.log("stopped")
        }

        findViewById<Button>(R.id.scanBtn).setOnClickListener {
            WebHolder.web.evaluateJavascript("window.__ov ? window.__ov.scan() : 'page not ready'", null)
        }

        findViewById<Button>(R.id.bgBtn).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
    }

    override fun onDestroy() {
        WebHolder.logListener = null
        container.removeAllViews()   // WebView stays alive inside WebHolder
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (WebHolder.web.canGoBack()) WebHolder.web.goBack() else super.onBackPressed()
    }
}
