package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Holds the one WebView + Engine so they survive when the Activity is closed. */
object WebHolder {
    const val DEFAULT_URL = "https://m.pocketoption.com/en/cabinet/"
    lateinit var web: WebView
    lateinit var engine: Engine
    val cfg = Config()
    val logBuf = StringBuilder()
    var logListener: ((String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private var inited = false

    @SuppressLint("SetJavaScriptEnabled")
    fun ensure(app: Context) {
        if (inited) return
        inited = true
        val prefs = app.getSharedPreferences("ov", 0)
        cfg.load(prefs)
        web = WebView(app)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(app), "AppModule")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(OVERLAY_JS, null)
            }
        }
        web.onResume()
        web.resumeTimers()
        engine = Engine(web, cfg) { log(it) }
        web.loadUrl(prefs.getString("url", null) ?: DEFAULT_URL)
    }

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "$t $msg"
        main.post {
            logBuf.append(line).append('\n')
            if (logBuf.length > 8000) logBuf.delete(0, 2000)
            logListener?.invoke(line)
        }
    }
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface fun log(msg: String) = WebHolder.log(msg)

    @JavascriptInterface fun copy(text: String) {
        Handler(Looper.getMainLooper()).post {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("scan", text))
            WebHolder.log("scan copied (" + text.lines().size + " lines) - paste it to Claude")
        }
    }
}

/**
 * Injected on every page load. Finds BUY/SELL, the amount box, the balance and the
 * demo label by their visible text and position, so no CSS selectors are needed.
 * "Scan page" still copies a list of page elements as a backup for debugging.
 */
const val OVERLAY_JS = """
(function(){
  if (window.__ov) return;
  function all(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function txt(e){ return (e.innerText || e.textContent || '').trim(); }

  // largest visible element whose whole text is exactly the word (the button itself)
  function findExact(word){
    var best = null, bestArea = 0;
    all('button, a, div, span').forEach(function(e){
      if (!vis(e) || txt(e).toUpperCase() !== word) return;
      var r = e.getBoundingClientRect(), a = r.width * r.height;
      if (a > bestArea) { best = e; bestArea = a; }
    });
    return best;
  }

  function accountLabel(){
    var leaves = all('*').filter(function(e){
      return e.children.length === 0 && vis(e) && e.getBoundingClientRect().top < 360;
    });
    for (var i = 0; i < leaves.length; i++) {
      if (/\b(demo|real)\b/i.test(txt(leaves[i]))) return leaves[i];
    }
    return null;
  }

  function balanceEl(){
    var lab = accountLabel(); if (!lab) return null;
    var p = lab.parentElement;
    for (var i = 0; i < 5 && p; i++, p = p.parentElement) {
      var kids = all('*', p);
      for (var k = 0; k < kids.length; k++) {
        var e = kids[k];
        if (e.children.length === 0 && vis(e) && /^-?[\d\s,]*\d\.\d{2}$/.test(txt(e))) return e;
      }
    }
    return null;
  }

  function amountEl(){
    var buy = findExact('BUY');
    var top = buy ? buy.getBoundingClientRect().top : 1e9;
    var c = all('input').filter(function(e){
      return vis(e) && /^[\d.,]+$/.test(e.value || '') && e.getBoundingClientRect().bottom <= top + 5;
    });
    c.sort(function(a, b){ return b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom; });
    return c[0] || null;
  }

  function setVal(el, v){
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    set.call(el, String(v));
    el.dispatchEvent(new Event('input', {bubbles: true}));
    el.dispatchEvent(new Event('change', {bubbles: true}));
    el.dispatchEvent(new Event('blur', {bubbles: true}));
  }

  window.__ov = {
    isDemo: function(){
      var l = accountLabel();
      return !!l && /demo/i.test(txt(l));
    },
    balance: function(){
      var e = balanceEl(); if (!e) return null;
      var v = parseFloat(txt(e).replace(/[^0-9.\-]/g, ''));
      return isNaN(v) ? null : v;
    },
    trade: function(asset, dir, expiry, amount){
      var a = amountEl();
      if (a) setVal(a, amount); else AppModule.log('amount box not found');
      var b = findExact(dir === 'call' ? 'BUY' : 'SELL');
      if (!b) { AppModule.log('BUY/SELL button not found'); return false; }
      b.click();
      return true;
    },
    scan: function(){
      var out = [];
      var nodes = all('button, input, [class*="balance" i], [class*="call" i], [class*="put" i], [class*="demo" i], [class*="amount" i]');
      for (var i = 0; i < nodes.length && out.length < 80; i++) {
        var e = nodes[i];
        if (!vis(e)) continue;
        var cls = (typeof e.className === 'string' && e.className.trim()) ? '.' + e.className.trim().split(/\s+/).slice(0, 4).join('.') : '';
        var t = (e.innerText || e.value || '').trim().slice(0, 30).replace(/\n/g, ' ');
        out.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + cls + ' | ' + t);
      }
      AppModule.copy(out.join('\n'));
      return out.length;
    }
  };
})();
"""
