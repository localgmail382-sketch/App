package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Holds the one WebView + Engine so they survive when the Activity is closed. */
object WebHolder {
    const val DEFAULT_URL = "https://m.pocketoption.com/en/cabinet/"
    lateinit var web: WebView
    lateinit var engine: Engine
    val cfg = Config()

    @Volatile var pageReady = false
    @Volatile var zoomPercent = 50        // page zoom: 100 = normal, 50 = zoomed out to half
    @Volatile var scanUntil = 0L          // the page may copy to the clipboard only right after you tap Scan

    private val main = Handler(Looper.getMainLooper())
    private var inited = false
    private val loginHosts = listOf("accounts.google.com", "www.facebook.com", "m.facebook.com", "facebook.com", "appleid.apple.com")

    private fun hostOf(url: String?): String? {
        if (url == null) return null
        val u = Uri.parse(url)
        if (u.scheme != "https") return null
        return u.host?.lowercase()
    }

    /** The broker's own pages: the only place the overlay script is injected. */
    fun isBroker(url: String?): Boolean {
        val h = hostOf(url) ?: return false
        return h == "pocketoption.com" || h.endsWith(".pocketoption.com")
    }

    /** Navigation allow-list: broker + the social-login providers. Everything else is blocked. */
    fun isAllowed(url: String?): Boolean {
        if (isBroker(url)) return true
        val h = hostOf(url) ?: return false
        return loginHosts.contains(h)
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun ensure(app: Context) {
        if (inited) return
        val prefs = app.getSharedPreferences("ov", 0)
        cfg.load(prefs)
        zoomPercent = prefs.getInt("zoom", 50)
        val w = WebView(app)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.useWideViewPort = true          // needed so the page's layout width can be changed (zoom)
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true      // pinch zoom still works as a backup
        w.settings.displayZoomControls = false
        w.addJavascriptInterface(Bridge(app), "AppModule")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString()
                val ok = isAllowed(url)
                if (!ok) log("blocked navigation to " + (request?.url?.host ?: "unknown site"))
                return !ok
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                pageReady = false
                if (isBroker(url)) view?.evaluateJavascript(HOOK_JS, null)   // fallback if document-start is unsupported
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (isBroker(url)) {
                    view?.evaluateJavascript(OVERLAY_JS) { pageReady = true }
                    applyZoom()
                    main.postDelayed({ applyZoom() }, 1500)      // again, in case the page rewrites its viewport
                }
            }
        }
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(w, HOOK_JS, setOf("https://*.pocketoption.com", "https://pocketoption.com"))
            }
        } catch (e: Throwable) {
            log("document-start hook unavailable: " + e.javaClass.simpleName)
        }
        if (Build.VERSION.SDK_INT >= 26) {
            w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)   // keep the page alive in the background
        }
        w.onResume()
        w.resumeTimers()
        web = w
        val eng = Engine(w, cfg) { log(it) }
        eng.onFinished = { app.stopService(Intent(app, TraderService::class.java)) }
        eng.onHistoryChanged = { HistoryStore.save(prefs) }
        engine = eng
        HistoryStore.load(prefs)
        eng.refreshStake()
        inited = true                       // only after everything above succeeded
        w.loadUrl(prefs.getString("url", null)?.takeIf { isAllowed(it) } ?: DEFAULT_URL)
    }

    /** Zooms the broker page by giving it a wider layout (50% = twice as wide, so everything looks half size). */
    fun applyZoom() {
        if (!inited) return
        val z = zoomPercent.coerceIn(30, 100) / 100.0
        val js = "(function(z){var w=Math.round((window.screen.width||360)/z);" +
            "var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}" +
            "m.setAttribute('content','width='+w+', initial-scale='+z+', minimum-scale='+Math.min(z,0.25)+', maximum-scale=3, user-scalable=yes');" +
            "})($z);"
        web.evaluateJavascript(js, null)
    }

    fun setZoom(p: SharedPreferences, percent: Int) {
        zoomPercent = percent
        p.edit().putInt("zoom", percent).apply()
        applyZoom()
    }

    /** Called every few seconds while running so Android does not freeze the page. */
    fun keepAlive() {
        if (!inited) return
        web.onResume()
        web.resumeTimers()
    }

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "$t $msg"
        main.post {
            Ui.logLines.add(line)
            while (Ui.logLines.size > 300) Ui.logLines.removeAt(0)
        }
    }
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface fun log(msg: String) = WebHolder.log(msg.take(300))

    @JavascriptInterface fun copy(text: String) {
        if (System.currentTimeMillis() > WebHolder.scanUntil) return   // only right after "Scan page"
        Handler(Looper.getMainLooper()).post {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("scan", text))
            WebHolder.log("scan copied (" + text.lines().size + " lines) - paste it to Claude")
        }
    }
}

/**
 * Injected on broker pages only. Uses the real Pocket Option mobile selectors.
 * Anything it cannot read returns null/'unknown' and the app then refuses to trade.
 */
const val OVERLAY_JS = """
(function(){
  if (window.__ov) return;
  function q(s){ return document.querySelector(s); }
  function all(s, r){ return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function txt(e){ return (e.innerText || e.textContent || '').trim(); }
  function firstVis(s){ return all(s).filter(vis)[0] || null; }

  // "21.56", "1,234.56", "1.234,56" and "21,56" all become numbers
  function parseMoney(s){
    s = String(s).replace(/[^0-9.,\-]/g, '');
    var lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    if (lc > -1 && ld > -1) {
      if (lc > ld) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (lc > -1) {
      if (/,\d{1,2}$/.test(s)) s = s.replace(',', '.');
      else s = s.replace(/,/g, '');
    }
    var v = parseFloat(s);
    return isNaN(v) ? null : v;
  }

  function setVal(el, v){
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    set.call(el, String(v));
    el.dispatchEvent(new Event('input', {bubbles: true}));
    el.dispatchEvent(new Event('change', {bubbles: true}));
    el.dispatchEvent(new Event('blur', {bubbles: true}));
  }

  function readAmt(){
    var b = q('.block--bet-amount'); if (!b) return null;
    var i = b.querySelector('input');
    return parseMoney(i ? i.value : txt(b));
  }

  window.__ov = {
    // 'demo' | 'real' | 'unknown'  (unknown = the app will not trade)
    accountType: function(){
      var l = q('.balance-info-block__label');
      var t = l ? txt(l) : '';
      if (/demo/i.test(t) || q('.balance-item--current.balance-item--demo') || document.body.classList.contains('is-chart-demo')) return 'demo';
      if (/real/i.test(t) || q('.balance-item--current.balance-item--real') || document.body.classList.contains('is-chart-real')) return 'real';
      return 'unknown';
    },
    balance: function(){
      var e = q('.balance-info-block__balance'); if (!e) return null;
      return parseMoney(txt(e));
    },
    payout: function(){
      var b = firstVis('.btn-call'); if (!b) return null;
      var m = txt(b).match(/\+(\d+)%/);
      return m ? (+m[1]) / 100 : null;
    },
    // 'c<secondsLeft>' = clock mode (e.g. 16:27:00), 't<seconds>' = timer mode (e.g. 00:01:00)
    expiry: function(){
      var b = q('.block--expiration-inputs'); if (!b) return null;
      var m = txt(b).match(/(\d+):(\d+)(?::(\d+))?/); if (!m) return null;
      if (m[3] === undefined) return 't' + ((+m[1]) * 60 + (+m[2]));
      var h = +m[1], mi = +m[2], se = +m[3];
      var now = new Date();
      var t = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, mi, se, 0);
      var d = (t - now) / 1000;
      if (d <= 0) d += 86400;                       // expiry just after midnight
      var nearMidnight = (now.getHours() === 23 || now.getHours() === 0);
      var mode;
      if (d > 1800) mode = 't';
      else if (h !== 0) mode = 'c';
      else if (nearMidnight) mode = window.__ovMode || 'c';   // ambiguous around midnight: keep last known
      else mode = 't';
      if (h !== 0 || !nearMidnight) window.__ovMode = mode;
      if (mode === 'c') return 'c' + d.toFixed(1);
      return 't' + (h * 3600 + mi * 60 + se);
    },
    buttons: function(){
      return !!firstVis('.btn-call') && !!firstVis('.btn-put');
    },
    amount: function(){ return readAmt(); },
    // the asset label in the chart header, e.g. 'AUD/CAD OTC' (exact text only, null if not found)
    selectedAsset: function(){
      var limit = window.innerHeight * 0.45;
      var els = all('*');
      for (var i = 0; i < els.length; i++) {
        var e = els[i];
        if (e.children.length > 3) continue;
        var r = e.getBoundingClientRect();
        if (r.width === 0 || r.height === 0 || r.top > limit) continue;
        var t = txt(e).replace(/\s+/g, ' ');
        if (/^[A-Za-z]{3}\/[A-Za-z]{3}( OTC)?$/i.test(t)) return t.toUpperCase();
      }
      return null;
    },
    amountOk: function(v){
      var a = readAmt();
      return a !== null && Math.abs(a - v) < 0.001;
    },
    setAmount: function(v){
      var b = q('.block--bet-amount'); if (!b) return 'noblock';
      var i = b.querySelector('input');
      if (i) { setVal(i, v); return 'input'; }
      var ce = b.querySelector('[contenteditable]');
      if (ce) {
        ce.focus(); ce.textContent = String(v);
        ce.dispatchEvent(new Event('input', {bubbles: true}));
        ce.dispatchEvent(new Event('blur', {bubbles: true}));
        return 'contenteditable';
      }
      return 'none';
    },
    // returns seconds until the trade ends; -1 failed, -2 clock expiry too close, -3 expiry too long
    click: function(dir, maxLeft){
      var el = firstVis(dir === 'call' ? '.btn-call' : '.btn-put');
      if (!el) { AppModule.log('BUY/SELL button not found'); return -1; }
      var info = window.__ov.expiry();
      if (!info) return -1;
      var left = parseFloat(info.slice(1));
      if (isNaN(left)) return -1;
      if (info.charAt(0) === 'c') {
        if (left < 20) return -2;
        if (maxLeft && left > maxLeft) return -3;
      }
      el.click();
      return left;
    },
    scan: function(){
      var out = [];
      var b = q('.block--bet-amount');
      if (b) out.push('AMOUNT_BLOCK_HTML: ' + b.outerHTML.slice(0, 1500));
      var x = q('.block--expiration-inputs');
      if (x) out.push('EXPIRY_BLOCK_HTML: ' + x.outerHTML.slice(0, 1500));
      var nodes = all('button, input, [class*="balance" i], [class*="call" i], [class*="put" i], [class*="demo" i], [class*="amount" i], [class*="bet" i], [class*="trade" i], [class*="deal" i]');
      for (var i = 0; i < nodes.length && out.length < 90; i++) {
        var e = nodes[i];
        if (!vis(e)) continue;
        var cls = (typeof e.className === 'string' && e.className.trim()) ? '.' + e.className.trim().split(/\s+/).slice(0, 4).join('.') : '';
        var t = (e.innerText || e.value || '').trim().slice(0, 30).replace(/\n/g, ' ');
        out.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + cls + ' | ' + t);
      }
      AppModule.copy(out.join('\n'));
      return out.length;
    }
  };
})();
"""

/**
 * Runs as early as possible on broker pages. It only LISTENS to the page's own websocket
 * (nothing is sent or changed) and keeps the trade events the broker reports:
 * opened / rejected / closed deals. The app reads them through window.__ovEv.drain().
 */
const val HOOK_JS = """
(function(){
  if (window.__ovEv) return;
  // the page must believe it is always visible, otherwise it may pause or drop its connection in the background
  try {
    Object.defineProperty(document, 'hidden', {get: function(){ return false; }, configurable: true});
    Object.defineProperty(document, 'visibilityState', {get: function(){ return 'visible'; }, configurable: true});
    document.addEventListener('visibilitychange', function(e){ e.stopImmediatePropagation(); }, true);
  } catch (e) {}
  var Q = [], last = 0, socks = 0;
  var WANT = {successopenOrder:1, failopenOrder:1, successcloseOrder:1, updateClosedDeals:1};
  window.__ovEv = {
    alive: function(){ return socks > 0 && (Date.now() - last) < 40000; },
    drain: function(){ var o = Q.slice(); Q.length = 0; return JSON.stringify(o); }
  };
  function push(n, p){ Q.push({n: n, p: p, t: Date.now()}); if (Q.length > 200) Q.shift(); }
  function dispatch(n, p){ if (WANT[n]) push(n, p); }
  function onFrame(st, d){
    last = Date.now();
    if (typeof d === 'string') {
      var m = d.match(/^45\d*-\["([^"]+)"/);          // binary event header, payload follows as the next frame
      if (m) { st.pend = WANT[m[1]] ? m[1] : null; return; }
      if (/^42\d*\[/.test(d)) {
        var arr = JSON.parse(d.slice(d.indexOf('[')));
        dispatch(arr[0], arr[1]);
      }
      return;
    }
    if (st.pend) {
      var name = st.pend; st.pend = null;
      var cb = function(txt){ try { dispatch(name, JSON.parse(txt)); } catch (e) {} };
      if (d instanceof ArrayBuffer) cb(new TextDecoder('utf-8').decode(d));
      else if (d && typeof d.text === 'function') d.text().then(cb);
    }
  }
  var NativeWS = window.WebSocket;
  var H = function(url, proto){
    var ws = (proto === undefined) ? new NativeWS(url) : new NativeWS(url, proto);
    try {
      socks++;
      var st = {pend: null};
      ws.addEventListener('message', function(ev){ try { onFrame(st, ev.data); } catch (e) {} });
    } catch (e) {}
    return ws;
  };
  H.prototype = NativeWS.prototype;
  ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'].forEach(function(k){ H[k] = NativeWS[k]; });
  window.WebSocket = H;
})();
"""
