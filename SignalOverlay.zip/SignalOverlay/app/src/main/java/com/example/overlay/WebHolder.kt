package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Holds the one WebView + Engine so they survive when the Activity is closed. */
object WebHolder {
    const val DEFAULT_URL = "https://m.pocketoption.com/en/cabinet/"
    lateinit var web: WebView
    lateinit var engine: Engine
    val cfg = Config()
    val logBuf = StringBuilder()
    var logListener: ((String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private var inited = false

    @SuppressLint("SetJavaScriptEnabled")
    fun ensure(app: Context) {
        if (inited) return
        inited = true
        val prefs = app.getSharedPreferences("ov", 0)
        cfg.load(prefs)
        web = WebView(app)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(app), "AppModule")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(OVERLAY_JS, null)
            }
        }
        web.onResume()
        web.resumeTimers()
        engine = Engine(web, cfg) { log(it) }
        web.loadUrl(prefs.getString("url", null) ?: DEFAULT_URL)
    }

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "$t $msg"
        main.post {
            logBuf.append(line).append('\n')
            if (logBuf.length > 8000) logBuf.delete(0, 2000)
            logListener?.invoke(line)
        }
    }
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface fun log(msg: String) = WebHolder.log(msg)

    @JavascriptInterface fun copy(text: String) {
        Handler(Looper.getMainLooper()).post {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("scan", text))
            WebHolder.log("scan copied (" + text.lines().size + " lines) - paste it to Claude")
        }
    }
}

/**
 * Injected on every page load.
 * !! SELECTORS are placeholders - tap "Scan page", paste the result to Claude,
 * and replace them with the real ones.
 */
const val OVERLAY_JS = """
(function(){
  if (window.__ov) return;
  var SEL = {
    call:    '.btn-call',        // TODO
    put:     '.btn-put',         // TODO
    amount:  'input.amount',     // TODO
    demo:    '.balance-demo',    // TODO: exists only on demo account
    balance: '.balance-value'    // TODO: element showing current balance
  };
  function q(s){ return document.querySelector(s); }
  function setVal(el, v){
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
    set.call(el, String(v));
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  window.__ov = {
    isDemo: function(){ return !!q(SEL.demo); },
    balance: function(){
      var e = q(SEL.balance); if (!e) return null;
      var v = parseFloat((e.innerText || e.textContent || '').replace(/[^0-9.\-]/g,''));
      return isNaN(v) ? null : v;
    },
    trade: function(asset, dir, expiry, amount){
      // TODO: switch asset/expiry in the page UI if they differ
      var a = q(SEL.amount); if (a) setVal(a, amount);
      var b = q(dir === 'call' ? SEL.call : SEL.put);
      if (!b) return false;
      b.click();
      return true;
    },
    scan: function(){
      var out = [];
      var nodes = document.querySelectorAll('button, input, [class*="balance" i], [class*="call" i], [class*="put" i], [class*="demo" i], [class*="amount" i], [class*="higher" i], [class*="lower" i]');
      for (var i = 0; i < nodes.length && out.length < 80; i++) {
        var e = nodes[i], r = e.getBoundingClientRect();
        if (r.width === 0 && r.height === 0) continue;
        var cls = (typeof e.className === 'string' && e.className.trim()) ? '.' + e.className.trim().split(/\s+/).slice(0,4).join('.') : '';
        var txt = (e.innerText || e.value || '').trim().slice(0,30).replace(/\n/g,' ');
        out.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + cls + ' | ' + txt);
      }
      AppModule.copy(out.join('\n'));
      return out.length;
    }
  };
})();
"""
