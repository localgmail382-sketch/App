package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Holds the one WebView + Engine so they survive when the Activity is closed. */
object WebHolder {
    const val DEFAULT_URL = "https://m.pocketoption.com/en/cabinet/"
    lateinit var web: WebView
    lateinit var engine: Engine
    val cfg = Config()
    val logBuf = StringBuilder()
    var logListener: ((String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private var inited = false

    @SuppressLint("SetJavaScriptEnabled")
    fun ensure(app: Context) {
        if (inited) return
        inited = true
        val prefs = app.getSharedPreferences("ov", 0)
        cfg.load(prefs)
        web = WebView(app)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(app), "AppModule")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(OVERLAY_JS, null)
            }
        }
        web.onResume()
        web.resumeTimers()
        engine = Engine(web, cfg) { log(it) }
        web.loadUrl(prefs.getString("url", null) ?: DEFAULT_URL)
    }

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "$t $msg"
        main.post {
            logBuf.append(line).append('\n')
            if (logBuf.length > 8000) logBuf.delete(0, 2000)
            logListener?.invoke(line)
        }
    }
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface fun log(msg: String) = WebHolder.log(msg)

    @JavascriptInterface fun copy(text: String) {
        Handler(Looper.getMainLooper()).post {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("scan", text))
            WebHolder.log("scan copied (" + text.lines().size + " lines) - paste it to Claude")
        }
    }
}

/**
 * Injected on every page load. Uses the real Pocket Option mobile selectors
 * (from your scan). "Scan page" also dumps the bet-amount block HTML for debugging.
 */
const val OVERLAY_JS = """
(function(){
  if (window.__ov) return;
  function q(s){ return document.querySelector(s); }
  function all(s, r){ return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function txt(e){ return (e.innerText || e.textContent || '').trim(); }
  function firstVis(s){ return all(s).filter(vis)[0] || null; }

  function setVal(el, v){
    var set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    set.call(el, String(v));
    el.dispatchEvent(new Event('input', {bubbles: true}));
    el.dispatchEvent(new Event('change', {bubbles: true}));
    el.dispatchEvent(new Event('blur', {bubbles: true}));
  }

  function readAmt(){
    var b = q('.block--bet-amount'); if (!b) return null;
    var i = b.querySelector('input');
    var t = i ? i.value : txt(b);
    var m = String(t).replace(/,/g, '').match(/\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  }

  window.__ov = {
    isDemo: function(){
      var l = q('.balance-info-block__label');
      if (l && /demo/i.test(txt(l))) return true;
      return document.body.classList.contains('is-chart-demo');
    },
    balance: function(){
      var e = q('.balance-info-block__balance'); if (!e) return null;
      var v = parseFloat(txt(e).replace(/[^0-9.\-]/g, ''));
      return isNaN(v) ? null : v;
    },
    expiry: function(){
      // returns 'c<secondsLeft>' for clock mode (e.g. 16:27:00) or 't<seconds>' for timer mode
      var b = q('.block--expiration-inputs'); if (!b) return null;
      var m = txt(b).match(/(\d+):(\d+)(?::(\d+))?/); if (!m) return null;
      if (m[3] === undefined) return 't' + ((+m[1]) * 60 + (+m[2]));
      var h = +m[1], mi = +m[2], se = +m[3];
      var now = new Date();
      var t = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, mi, se, 0);
      var d = (t - now) / 1000;
      if (d > 0 && d <= 1800) return 'c' + d.toFixed(1);
      return 't' + (h * 3600 + mi * 60 + se);
    },
    amountOk: function(v){
      var a = readAmt();
      return a !== null && Math.abs(a - v) < 0.001;
    },
    setAmount: function(v){
      var b = q('.block--bet-amount'); if (!b) return 'noblock';
      var i = b.querySelector('input');
      if (i) { setVal(i, v); return 'input'; }
      var ce = b.querySelector('[contenteditable]');
      if (ce) {
        ce.focus(); ce.textContent = String(v);
        ce.dispatchEvent(new Event('input', {bubbles: true}));
        ce.dispatchEvent(new Event('blur', {bubbles: true}));
        return 'contenteditable';
      }
      return 'none';
    },
    click: function(dir){
      // returns seconds until the trade ends, -1 = failed, -2 = clock expiry too close (retry)
      var el = firstVis(dir === 'call' ? '.btn-call' : '.btn-put');
      if (!el) { AppModule.log('BUY/SELL button not found'); return -1; }
      var info = window.__ov.expiry();
      if (!info) return -1;
      var left = parseFloat(info.slice(1));
      if (isNaN(left)) return -1;
      if (info.charAt(0) === 'c' && left < 20) return -2;
      el.click();
      return left;
    },
    scan: function(){
      var out = [];
      var b = q('.block--bet-amount');
      if (b) out.push('AMOUNT_BLOCK_HTML: ' + b.outerHTML.slice(0, 1500));
      var x = q('.block--expiration-inputs');
      if (x) out.push('EXPIRY_BLOCK_HTML: ' + x.outerHTML.slice(0, 1500));
      var nodes = all('button, input, [class*="balance" i], [class*="call" i], [class*="put" i], [class*="demo" i], [class*="amount" i], [class*="bet" i]');
      for (var i = 0; i < nodes.length && out.length < 80; i++) {
        var e = nodes[i];
        if (!vis(e)) continue;
        var cls = (typeof e.className === 'string' && e.className.trim()) ? '.' + e.className.trim().split(/\s+/).slice(0, 4).join('.') : '';
        var t = (e.innerText || e.value || '').trim().slice(0, 30).replace(/\n/g, ' ');
        out.push(e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + cls + ' | ' + t);
      }
      AppModule.copy(out.join('\n'));
      return out.length;
    }
  };
})();
"""
