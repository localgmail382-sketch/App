package com.example.overlay

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Signal text format (one per line, case-insensitive):
 *   [HH:mm] ASSET CALL|PUT [expirySec] [amount]
 * Examples:
 *   14:05 EURUSD_otc CALL 60 1
 *   GBPUSD PUT            <- no time = next candle open
 */
data class Signal(
    val asset: String,
    val dir: String,          // "call" or "put"
    val hour: Int?,           // null = next candle
    val minute: Int?,
    val expirySec: Int,
    val amount: Double
)

object SignalParser {
    private val re = Regex(
        """^(?:(\d{1,2}):(\d{2})\s+)?([A-Za-z0-9_/\-]+)\s+(CALL|PUT|BUY|SELL|UP|DOWN)(?:\s+(\d+))?(?:\s+(\d+(?:\.\d+)?))?$""",
        RegexOption.IGNORE_CASE
    )

    fun parse(text: String, defExpiry: Int = 60, defAmount: Double = 1.0): List<Signal> =
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { line ->
            val m = re.matchEntire(line) ?: return@mapNotNull null
            val g = m.groupValues
            val d = when (g[4].uppercase()) { "CALL", "BUY", "UP" -> "call" else -> "put" }
            Signal(
                asset = g[3], dir = d,
                hour = g[1].toIntOrNull(), minute = g[2].toIntOrNull(),
                expirySec = g[5].toIntOrNull() ?: defExpiry,
                amount = g[6].toDoubleOrNull() ?: defAmount
            )
        }
}

class Risk(
    var maxStake: Double = 5.0,
    var maxConsecLosses: Int = 3,
    var dailyLossLimit: Double = 20.0,
    var allowReal: Boolean = false      // demo only until you flip this
) {
    var consecLosses = 0
    var dailyLoss = 0.0
    fun canTrade(stake: Double, isDemo: Boolean): Boolean =
        (isDemo || allowReal) && stake <= maxStake &&
        consecLosses < maxConsecLosses && dailyLoss < dailyLossLimit

    fun onResult(win: Boolean, stake: Double) {
        if (win) consecLosses = 0 else { consecLosses++; dailyLoss += stake }
    }
}

class SignalTrader(private val web: WebView, private val risk: Risk, private val onLog: (String) -> Unit = {}) {
    private val h = Handler(Looper.getMainLooper())
    private val queue = mutableListOf<Signal>()
    private val fired = HashSet<String>()
    var latencyMs = 150L              // tune: fire slightly early to land on candle open
    var maxLateMs = 2000L             // skip if we missed the candle by more than this

    fun load(text: String): Int {
        queue.clear(); queue += SignalParser.parse(text); schedule(); return queue.size
    }

    fun stop() { h.removeCallbacksAndMessages(null); queue.clear(); fired.clear() }

    private fun schedule() {
        queue.forEach { s ->
            val now = System.currentTimeMillis()
            val target = nextOpen(s, now)
            val key = "${s.asset}|${s.dir}|$target"
            if (!fired.add(key)) return@forEach
            h.postDelayed({ fire(s, target) }, (target - now - latencyMs).coerceAtLeast(0))
        }
    }

    // candle open in ms (M1 candles). Use page/server time offset if the device clock drifts.
    private fun nextOpen(s: Signal, now: Long): Long {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        if (s.hour != null && s.minute != null) {
            cal.set(java.util.Calendar.HOUR_OF_DAY, s.hour)
            cal.set(java.util.Calendar.MINUTE, s.minute)
            cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
            if (cal.timeInMillis < now - maxLateMs) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }
        return (now / 60_000 + 1) * 60_000
    }

    private fun fire(s: Signal, target: Long) {
        if (System.currentTimeMillis() - target > maxLateMs) { onLog("skip (late): ${s.asset} ${s.dir}"); return }
        // ask the page whether we're on demo, then trade
        web.evaluateJavascript("window.__ov.isDemo()") { r ->
            val isDemo = r?.contains("true") == true
            if (!risk.canTrade(s.amount, isDemo)) {
                onLog("blocked by risk rules (demo=$isDemo, losses=${risk.consecLosses}, dayLoss=${risk.dailyLoss})")
                return@evaluateJavascript
            }
            web.evaluateJavascript(
                "window.__ov.trade('${s.asset}','${s.dir}',${s.expirySec},${s.amount})", null
            )
        }
    }
}

/** Page -> app: the injected JS reports results here. */
class Bridge(private val risk: Risk, private val onLog: (String) -> Unit) {
    @JavascriptInterface fun result(win: Boolean, stake: Double) {
        risk.onResult(win, stake); onLog("result win=$win stake=$stake")
    }
    @JavascriptInterface fun log(msg: String) = onLog(msg)
}

/**
 * JS injected on every page load (WebViewClient.onPageFinished -> evaluateJavascript(OVERLAY_JS)).
 * !! The SELECTORS below are placeholders. Open the broker page in Chrome on PC
 * (or chrome://inspect for the phone WebView), inspect the Buy/Sell buttons, amount
 * input, asset switcher and demo/real indicator, then replace them.
 */
const val OVERLAY_JS = """
(function(){
  if (window.__ov) return;
  const SEL = {
    call:   '.btn-call',          // TODO
    put:    '.btn-put',           // TODO
    amount: 'input.amount',       // TODO
    demo:   '.balance-demo'       // TODO: element/class present only on demo
  };
  const q = s => document.querySelector(s);
  function setVal(el, v){
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
    set.call(el, String(v));
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  window.__ov = {
    isDemo: () => !!q(SEL.demo),
    trade: (asset, dir, expiry, amount) => {
      // TODO: switch asset + expiry via the UI if different from current
      const a = q(SEL.amount); if (a) setVal(a, amount);
      const b = q(dir === 'call' ? SEL.call : SEL.put);
      if (b) { b.click(); AppModule.log('clicked '+dir+' '+asset); }
      else AppModule.log('button not found');
    }
  };
})();
"""
