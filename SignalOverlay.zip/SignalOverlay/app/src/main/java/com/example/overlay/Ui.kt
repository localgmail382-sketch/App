package com.example.overlay

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** One signal row on screen. status: pending, waiting, live, won, lost, draw, skipped */
class SigItem(val id: Int, val at: Long, val timeLabel: String, val asset: String, val dir: String) {
    var status by mutableStateOf("pending")
    var note by mutableStateOf("")
}

class HistoryItem(
    val time: String, val asset: String, val dir: String,
    val stake: Double, val step: Int, val result: String, val pnl: Double
)

class PreCheck(val label: String, val ok: Boolean, val detail: String)

/** Everything the screens show. Written by the engine on the main thread. */
object Ui {
    var running by mutableStateOf(false)
    var statusText by mutableStateOf("Stopped")
    var nextAt by mutableStateOf(0L)
    var nextText by mutableStateOf("")
    var step by mutableStateOf(0)
    var nextStake by mutableStateOf(1.0)
    var wins by mutableStateOf(0)
    var losses by mutableStateOf(0)
    var pnl by mutableStateOf(0.0)
    var balance by mutableStateOf<Double?>(null)
    var signalText by mutableStateOf("")
    var listInfo by mutableStateOf("")
    var checking by mutableStateOf(false)
    val cards = mutableStateListOf<SigItem>()
    val history = mutableStateListOf<HistoryItem>()
    val logLines = mutableStateListOf<String>()
    val checks = mutableStateListOf<PreCheck>()
}

fun money(d: Double): String = String.format(Locale.US, "%.2f", d)

/** "AUDCAD_otc" -> "AUD/CAD OTC"; null if it is not a plain 6-letter pair. */
fun pairText(a: String): String? {
    val otc = a.endsWith("_otc", ignoreCase = true)
    val core = a.replace("_otc", "", ignoreCase = true).replace("_", "").replace("/", "")
    if (core.length != 6 || !core.all { it.isLetter() }) return null
    val base = core.substring(0, 3).uppercase() + "/" + core.substring(3).uppercase()
    return if (otc) "$base OTC" else base
}

fun prettyAsset(a: String): String =
    pairText(a) ?: a.replace("_otc", " OTC", ignoreCase = true).replace("_", " ").uppercase()
