package com.example.overlay

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** One signal row on screen. status: pending, waiting, live, won, lost, draw, skipped, unknown */
class SigItem(val id: Int, val at: Long, val timeLabel: String, val asset: String, val dir: String) {
    var status by mutableStateOf("pending")
    var note by mutableStateOf("")
}

class HistoryItem(
    val day: String, val time: String, val asset: String, val dir: String,
    val stake: Double, val step: Int, val result: String, val pnl: Double
)

class PreCheck(val label: String, val ok: Boolean, val detail: String)

/** Everything the screens show. Written by the engine on the main thread. */
object Ui {
    var running by mutableStateOf(false)
    var statusText by mutableStateOf("Stopped")
    var nextAt by mutableStateOf(0L)
    var nextText by mutableStateOf("")
    var step by mutableStateOf(0)
    var nextStake by mutableStateOf(1.0)
    var wins by mutableStateOf(0)
    var losses by mutableStateOf(0)
    var draws by mutableStateOf(0)
    var pnl by mutableStateOf(0.0)
    var dailyLoss by mutableStateOf(0.0)
    var balance by mutableStateOf<Double?>(null)
    var payout by mutableStateOf<Double?>(null)
    var accountType by mutableStateOf("")
    var signalText by mutableStateOf("")
    var listInfo by mutableStateOf("")
    var checking by mutableStateOf(false)
    val cards = mutableStateListOf<SigItem>()
    val history = mutableStateListOf<HistoryItem>()
    val logLines = mutableStateListOf<String>()
    val checks = mutableStateListOf<PreCheck>()
    val parseErrors = mutableStateListOf<String>()
}

/** Keeps the trade ledger across app restarts. */
object HistoryStore {
    fun save(p: SharedPreferences) {
        val sb = StringBuilder()
        for (h in Ui.history.takeLast(500)) {
            sb.append(h.day).append('|').append(h.time).append('|').append(h.asset).append('|')
                .append(h.dir).append('|').append(h.stake).append('|').append(h.step).append('|')
                .append(h.result).append('|').append(h.pnl).append('\n')
        }
        p.edit().putString("history", sb.toString()).apply()
    }

    fun load(p: SharedPreferences) {
        Ui.history.clear()
        Ui.wins = 0; Ui.losses = 0; Ui.draws = 0; Ui.pnl = 0.0
        val raw = p.getString("history", "") ?: ""
        for (line in raw.lines()) {
            val f = line.split('|')
            if (f.size < 8) continue
            val stake = f[4].toDoubleOrNull() ?: continue
            val step = f[5].toIntOrNull() ?: continue
            val pnl = f[7].toDoubleOrNull() ?: continue
            Ui.history.add(HistoryItem(f[0], f[1], f[2], f[3], stake, step, f[6], pnl))
            when (f[6]) {
                "WIN" -> Ui.wins++
                "LOSS" -> Ui.losses++
                "DRAW" -> Ui.draws++
            }
            Ui.pnl += pnl
        }
    }
}

fun money(d: Double): String = String.format(Locale.US, "%.2f", d)

/** "AUDCAD_otc" -> "AUD/CAD OTC"; null if it is not a plain 6-letter pair. */
fun pairText(a: String): String? {
    val otc = a.endsWith("_otc", ignoreCase = true)
    val core = a.replace("_otc", "", ignoreCase = true).replace("_", "").replace("/", "")
    if (core.length != 6 || !core.all { it.isLetter() }) return null
    val base = core.substring(0, 3).uppercase() + "/" + core.substring(3).uppercase()
    return if (otc) "$base OTC" else base
}

fun prettyAsset(a: String): String =
    pairText(a) ?: a.replace("_otc", " OTC", ignoreCase = true).replace("_", " ").uppercase()
