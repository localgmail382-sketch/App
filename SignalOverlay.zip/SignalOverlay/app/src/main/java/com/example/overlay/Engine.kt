package com.example.overlay

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * Runs the whole pasted list on its own clock.
 *
 * Martingale (signal-to-signal): every signal is traded with its OWN asset and
 * direction. The stake depends on the current step:
 *   step 0 -> base stake
 *   LOSS   -> step + 1 (stake * multiplier^step) for the NEXT signal, up to maxSteps
 *   WIN    -> back to step 0 (base stake)
 *   DRAW   -> step unchanged
 * If the next signal's time arrives before the previous trade has finished,
 * it waits for the result (a second or two) so it uses the right stake.
 */
class Engine(
    private val web: WebView,
    private val cfg: Config,
    private val log: (String) -> Unit
) {
    private class Slot(val s: Signal, val at: Long)

    private val h = Handler(Looper.getMainLooper())
    private var slots = listOf<Slot>()
    private var idx = 0
    private var busy = false          // a trade is being placed / waiting for its result
    private var waiting: Slot? = null // signal that arrived while busy
    private var step = 0
    private var gen = 0
    private var dailyLoss = 0.0

    fun start(text: String): Int {
        stop()
        step = 0
        val lines = text.lines().count { it.isNotBlank() }
        val sigs = SignalParser.parse(text)
        if (lines > sigs.size) log("ignored ${lines - sigs.size} unreadable line(s)")
        slots = buildSlots(sigs, System.currentTimeMillis())
        idx = 0
        log("loaded ${slots.size} signal(s)")
        scheduleNext(gen)
        return slots.size
    }

    fun stop() {
        gen++
        h.removeCallbacksAndMessages(null)
        busy = false
        waiting = null
    }

    private fun buildSlots(sigs: List<Signal>, now: Long): List<Slot> {
        val out = ArrayList<Slot>()
        var dayOffset = 0
        var prev = Long.MIN_VALUE
        for (s in sigs) {
            val hr = s.hour
            val mn = s.minute
            if (hr == null || mn == null) {
                val t = if (prev == Long.MIN_VALUE) (now / 60_000 + 1) * 60_000 else prev + 60_000
                out.add(Slot(s, t)); prev = t
                continue
            }
            val cal = Calendar.getInstance()
            cal.timeInMillis = now
            cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            cal.set(Calendar.HOUR_OF_DAY, hr)
            cal.set(Calendar.MINUTE, mn)
            cal.set(Calendar.SECOND, s.second)
            cal.set(Calendar.MILLISECOND, 0)
            var t = cal.timeInMillis
            if (t < prev) {            // list crossed midnight
                dayOffset++
                cal.add(Calendar.DAY_OF_YEAR, 1)
                t = cal.timeInMillis
            }
            out.add(Slot(s, t)); prev = t
        }
        return out
    }

    private fun scheduleNext(g: Int) {
        if (g != gen) return
        val now = System.currentTimeMillis()
        var expired = 0
        while (idx < slots.size && slots[idx].at + cfg.maxLateMs < now) { idx++; expired++ }
        if (expired > 0) log("skipped $expired expired signal(s)")
        if (idx >= slots.size) { log("no more signals queued"); return }
        val slot = slots[idx]
        val delay = (slot.at - now - cfg.latencyMs).coerceAtLeast(0)
        h.postDelayed({ fire(slot, g) }, delay)
    }

    private fun fire(slot: Slot, g: Int) {
        if (g != gen) return
        idx++
        scheduleNext(g)                       // arm the next signal first
        if (System.currentTimeMillis() - slot.at > cfg.maxLateMs) {
            log("skip (late): ${slot.s.asset} ${slot.s.dir}"); return
        }
        if (busy) {
            if (waiting != null) log("skip (replaced): ${waiting!!.s.asset} ${waiting!!.s.dir}")
            waiting = slot
            log("waiting for previous result: ${slot.s.asset} ${slot.s.dir}")
            return
        }
        trade(slot.s, g)
    }

    /** Previous trade is finished: run the signal that was waiting, if it is still fresh. */
    private fun finish(g: Int) {
        busy = false
        val w = waiting
        waiting = null
        if (w != null && g == gen) {
            if (System.currentTimeMillis() - w.at <= cfg.maxLateMs) trade(w.s, g)
            else log("skip (late after result): ${w.s.asset} ${w.s.dir}")
        }
    }

    private fun abort() { busy = false; waiting = null }

    private fun trade(s: Signal, g: Int) {
        if (g != gen) return
        busy = true
        if (dailyLoss >= cfg.dailyLossLimit) {
            log("daily loss limit reached - stopped")
            stop(); return
        }
        val stepNow = step
        val stake = (cfg.baseStake * cfg.multiplier.pow(stepNow) * 100).roundToLong() / 100.0
        web.evaluateJavascript("window.__ov.isDemo()") { r ->
            if (g != gen) return@evaluateJavascript
            val demo = r?.contains("true") == true
            if (!demo && !cfg.allowReal) {
                log("not demo and REAL not allowed - blocked")
                abort()
                return@evaluateJavascript
            }
            web.evaluateJavascript("window.__ov.balance()") { b0 ->
                if (g != gen) return@evaluateJavascript
                val before = num(b0)
                if (before == null) {
                    log("cannot read balance - fix the balance selector")
                    abort()
                    return@evaluateJavascript
                }
                val js = "window.__ov.trade('${s.asset}','${s.dir}',${s.expirySec},$stake)"
                web.evaluateJavascript(js) { ok ->
                    if (g != gen) return@evaluateJavascript
                    if (ok?.contains("true") != true) {
                        log("trade click failed - fix the button selectors")
                        abort()
                        return@evaluateJavascript
                    }
                    log("TRADE ${s.dir.uppercase()} ${s.asset} stake=$stake" + if (stepNow > 0) " (MTG$stepNow)" else "")
                    h.postDelayed({ settle(before, stake, g, 0) }, s.expirySec * 1000L + cfg.graceMs)
                }
            }
        }
    }

    private fun settle(before: Double, stake: Double, g: Int, attempt: Int) {
        if (g != gen) return
        web.evaluateJavascript("window.__ov.balance()") { b1 ->
            if (g != gen) return@evaluateJavascript
            val after = num(b1)
            if (after == null) {
                log("cannot read balance after trade - stopped")
                abort()
                return@evaluateJavascript
            }
            val eps = 0.005
            if (after > before + eps) {
                step = 0
                log("WIN +${fmt(after - before)} -> next stake = base")
                finish(g)
                return@evaluateJavascript
            }
            if (attempt == 0) {          // balance can lag: check once more before calling it
                h.postDelayed({ settle(before, stake, g, 1) }, 600)
                return@evaluateJavascript
            }
            if (abs(after - before) <= eps) {
                log("DRAW - next stake unchanged")
            } else {
                dailyLoss += stake
                if (step < cfg.maxSteps) {
                    step++
                    val next = (cfg.baseStake * cfg.multiplier.pow(step) * 100).roundToLong() / 100.0
                    log("LOSS -${fmt(stake)} -> next signal MTG$step stake=$next")
                } else {
                    step = 0
                    log("LOSS -${fmt(stake)}, MTG limit reached -> next stake = base")
                }
            }
            finish(g)
        }
    }

    private fun num(r: String?): Double? = r?.trim('"')?.toDoubleOrNull()
    private fun fmt(d: Double) = String.format(Locale.US, "%.2f", d)
}
