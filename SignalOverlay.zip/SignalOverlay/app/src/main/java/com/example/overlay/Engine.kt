package com.example.overlay

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Runs the whole pasted list on its own clock.
 *
 * Martingale (signal-to-signal): every signal is traded with its OWN asset and
 * direction. The stake depends on the current step:
 *   step 0 -> base stake
 *   LOSS   -> step + 1 (stake * multiplier^step) for the NEXT signal, up to maxSteps
 *   WIN    -> back to step 0 (base stake)
 *   DRAW   -> step unchanged
 * If the next signal's time arrives before the previous trade has finished,
 * it waits for the result (a second or two) so it uses the right stake.
 */
class Engine(
    private val web: WebView,
    private val cfg: Config,
    private val log: (String) -> Unit
) {
    private class Slot(val s: Signal, val at: Long)

    private val h = Handler(Looper.getMainLooper())
    private var slots = listOf<Slot>()
    private var idx = 0
    private var busy = false          // a trade is being placed / waiting for its result
    private var waiting: Slot? = null // signal that arrived while busy
    private var step = 0
    private var gen = 0
    private var dailyLoss = 0.0

    fun start(text: String): Int {
        stop()
        step = 0
        val lines = text.lines().count { it.isNotBlank() }
        val sigs = SignalParser.parse(text)
        if (lines > sigs.size) log("ignored ${lines - sigs.size} unreadable line(s)")
        slots = buildSlots(sigs, System.currentTimeMillis())
        idx = 0
        log("loaded ${slots.size} signal(s)")
        scheduleNext(gen)
        return slots.size
    }

    fun stop() {
        gen++
        h.removeCallbacksAndMessages(null)
        busy = false
        waiting = null
    }

    private fun buildSlots(sigs: List<Signal>, now: Long): List<Slot> {
        val out = ArrayList<Slot>()
        var dayOffset = 0
        var prev = Long.MIN_VALUE
        for (s in sigs) {
            val hr = s.hour
            val mn = s.minute
            if (hr == null || mn == null) {
                val t = if (prev == Long.MIN_VALUE) (now / 60_000 + 1) * 60_000 else prev + 60_000
                out.add(Slot(s, t)); prev = t
                continue
            }
            val cal = Calendar.getInstance()
            cal.timeInMillis = now
            cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            cal.set(Calendar.HOUR_OF_DAY, hr)
            cal.set(Calendar.MINUTE, mn)
            cal.set(Calendar.SECOND, s.second)
            cal.set(Calendar.MILLISECOND, 0)
            var t = cal.timeInMillis
            if (t < prev) {            // list crossed midnight
                dayOffset++
                cal.add(Calendar.DAY_OF_YEAR, 1)
                t = cal.timeInMillis
            }
            out.add(Slot(s, t)); prev = t
        }
        return out
    }

    private fun scheduleNext(g: Int) {
        if (g != gen) return
        val now = System.currentTimeMillis()
        var expired = 0
        while (idx < slots.size && slots[idx].at + cfg.maxLateMs < now) { idx++; expired++ }
        if (expired > 0) log("skipped $expired expired signal(s)")
        if (idx >= slots.size) { log("no more signals queued"); return }
        val slot = slots[idx]
        val delay = (slot.at - now - cfg.latencyMs).coerceAtLeast(0)
        h.postDelayed({ fire(slot, g) }, delay)
    }

    private fun fire(slot: Slot, g: Int) {
        if (g != gen) return
        idx++
        scheduleNext(g)                       // arm the next signal first
        if (System.currentTimeMillis() - slot.at > cfg.maxLateMs) {
            log("skip (late): ${slot.s.asset} ${slot.s.dir}"); return
        }
        if (busy) {
            if (waiting != null) log("skip (replaced): ${waiting!!.s.asset} ${waiting!!.s.dir}")
            waiting = slot
            log("waiting for previous result: ${slot.s.asset} ${slot.s.dir}")
            return
        }
        trade(slot.s, g)
    }

    /** Previous trade is finished: run the signal that was waiting, if it is still fresh. */
    private fun finish(g: Int) {
        busy = false
        val w = waiting
        waiting = null
        if (w != null && g == gen) {
            if (System.currentTimeMillis() - w.at <= cfg.maxLateMs) trade(w.s, g)
            else log("skip (late after result): ${w.s.asset} ${w.s.dir}")
        }
    }

    private fun abort() { busy = false; waiting = null }

    private fun trade(s: Signal, g: Int) {
        if (g != gen) return
        busy = true
        if (dailyLoss >= cfg.dailyLossLimit) {
            log("daily loss limit reached - stopped")
            stop(); return
        }
        val stepNow = step
        val stake = (cfg.baseStake * cfg.multiplier.pow(stepNow) * 100).roundToLong() / 100.0
        web.evaluateJavascript("window.__ov.isDemo()") { r ->
            if (g != gen) return@evaluateJavascript
            val demo = r?.contains("true") == true
            if (!demo && !cfg.allowReal) {
                log("not demo and REAL not allowed - blocked")
                abort()
                return@evaluateJavascript
            }
            web.evaluateJavascript("window.__ov.balance()") { b0 ->
                if (g != gen) return@evaluateJavascript
                val before = num(b0)
                if (before == null) {
                    log("cannot read balance")
                    abort()
                    return@evaluateJavascript
                }
                web.evaluateJavascript("window.__ov.expiry()") { e0 ->
                    if (g != gen) return@evaluateJavascript
                    val info = e0?.trim('"')
                    val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                    if (info == null || secs == null) {
                        log("cannot read expiry box")
                        abort()
                        return@evaluateJavascript
                    }
                    val clock = info[0] == 'c'
                    if (!clock && secs.toInt() != s.expirySec) {
                        log("timer expiry ${secs.toInt()}s but signal needs ${s.expirySec}s - set it by hand or use clock mode +M1")
                        abort()
                        return@evaluateJavascript
                    }
                    ensureAmount(stake, g) { okAmt ->
                        if (okAmt) {
                            placeTrades(s, g, 1, clock, stake, stepNow, before)
                            return@ensureAmount
                        }
                        // amount box can't be changed: build the stake from base-stake trades
                        val n = (stake / cfg.baseStake).roundToInt()
                        if (n < 1 || n > cfg.maxSplit) {
                            log("cannot set amount to $stake and $n split trades is over the limit - cancelled")
                            abort()
                            return@ensureAmount
                        }
                        web.evaluateJavascript("window.__ov.amountOk(${cfg.baseStake})") { r2 ->
                            if (g != gen) return@evaluateJavascript
                            if (r2?.contains("true") != true) {
                                log("amount box is not at ${cfg.baseStake} - cannot split trades")
                                abort()
                                return@evaluateJavascript
                            }
                            log("amount locked - placing $n x ${cfg.baseStake} instead of $stake")
                            placeTrades(s, g, n, clock, stake, stepNow, before)
                        }
                    }
                }
            }
        }
    }

    /** Places n trades of whatever amount the page shows, one after another. */
    private fun placeTrades(
        s: Signal, g: Int, n: Int, clock: Boolean,
        stake: Double, stepNow: Int, before: Double
    ) {
        var wanted = n
        var placed = 0
        var lastLeft = -1.0

        fun next() {
            if (g != gen) return
            if (placed >= wanted) {
                log("TRADE ${s.dir.uppercase()} ${s.asset} stake=$stake" +
                    (if (placed > 1) " as $placed x ${cfg.baseStake}" else "") +
                    (if (stepNow > 0) " (MTG$stepNow)" else "") +
                    (if (clock) " ends in ${fmt(lastLeft)}s" else ""))
                h.postDelayed({ settle(before, g, 0) }, (lastLeft * 1000).toLong() + cfg.graceMs)
                return
            }
            clickTrade(s, g, 0) { left ->
                if (left < 0) {
                    if (placed == 0) {
                        log("trade click failed")
                        abort()
                        return@clickTrade
                    }
                    log("only $placed of $n trades placed")
                    wanted = placed
                } else {
                    placed++
                    lastLeft = left
                }
                if (placed < wanted) h.postDelayed({ next() }, 250) else next()
            }
        }
        next()
    }

    /** Clicks BUY/SELL. Retries briefly if the clock expiry has not rolled over yet. */
    private fun clickTrade(s: Signal, g: Int, tries: Int, done: (Double) -> Unit) {
        web.evaluateJavascript("window.__ov.click('${s.dir}')") { r ->
            if (g != gen) return@evaluateJavascript
            val v = num(r) ?: -1.0
            if (v <= -1.5 && tries < 6) {
                h.postDelayed({ clickTrade(s, g, tries + 1, done) }, 200)
            } else {
                done(v)
            }
        }
    }

    /** Tries to make the page's amount equal the stake. false = can't (caller splits instead). */
    private fun ensureAmount(stake: Double, g: Int, done: (Boolean) -> Unit) {
        web.evaluateJavascript("window.__ov.amountOk($stake)") { r ->
            if (g != gen) return@evaluateJavascript
            if (r?.contains("true") == true) { done(true); return@evaluateJavascript }
            web.evaluateJavascript("window.__ov.setAmount($stake)") { m ->
                if (g != gen) return@evaluateJavascript
                if (m == null || m.contains("none") || m.contains("noblock")) {
                    done(false)                       // nothing editable - go straight to splitting
                    return@evaluateJavascript
                }
                h.postDelayed({
                    if (g == gen) {
                        web.evaluateJavascript("window.__ov.amountOk($stake)") { r2 ->
                            if (g == gen) done(r2?.contains("true") == true)
                        }
                    }
                }, 350)
            }
        }
    }

    private fun settle(before: Double, g: Int, attempt: Int) {
        if (g != gen) return
        web.evaluateJavascript("window.__ov.balance()") { b1 ->
            if (g != gen) return@evaluateJavascript
            val after = num(b1)
            if (after == null) {
                log("cannot read balance after trade - stopped")
                abort()
                return@evaluateJavascript
            }
            val eps = 0.005
            if (after > before + eps) {
                step = 0
                log("WIN +${fmt(after - before)} -> next stake = base")
                finish(g)
                return@evaluateJavascript
            }
            if (attempt == 0) {          // balance can lag: check once more before calling it
                h.postDelayed({ settle(before, g, 1) }, 500)
                return@evaluateJavascript
            }
            if (abs(after - before) <= eps) {
                log("DRAW - next stake unchanged")
            } else {
                val lost = before - after
                dailyLoss += lost
                if (step < cfg.maxSteps) {
                    step++
                    val next = (cfg.baseStake * cfg.multiplier.pow(step) * 100).roundToLong() / 100.0
                    log("LOSS -${fmt(lost)} -> next signal MTG$step stake=$next")
                } else {
                    step = 0
                    log("LOSS -${fmt(lost)}, MTG limit reached -> next stake = base")
                }
            }
            finish(g)
        }
    }

    private fun num(r: String?): Double? = r?.trim('"')?.toDoubleOrNull()
    private fun fmt(d: Double) = String.format(Locale.US, "%.2f", d)
}
