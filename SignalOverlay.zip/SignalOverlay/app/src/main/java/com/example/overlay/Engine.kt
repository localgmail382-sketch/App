package com.example.overlay

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Runs the pasted signal list on its own clock and reports everything to [Ui].
 *
 * Martingale (signal-to-signal): each signal is traded with its OWN asset and
 * direction. Stake = base * multiplier^step. LOSS -> step+1 for the next signal
 * (up to maxSteps), WIN -> step 0, DRAW -> unchanged. If the page's amount box
 * cannot be changed, the stake is built from several base-stake trades.
 */
class Engine(
    private val web: WebView,
    private val cfg: Config,
    private val log: (String) -> Unit
) {
    private class Slot(val s: Signal, val at: Long, val item: SigItem)

    var onFinished: (() -> Unit)? = null

    private val h = Handler(Looper.getMainLooper())
    private var slots = listOf<Slot>()
    private var idx = 0
    private var busy = false
    private var waiting: Slot? = null
    private var step = 0
    private var gen = 0
    private var dailyLoss = 0.0
    private var lossDay = ""
    private val fmtHm = SimpleDateFormat("HH:mm", Locale.US)
    private val fmtHms = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val fmtDay = SimpleDateFormat("yyyyMMdd", Locale.US)

    private fun stakeFor(st: Int) = (cfg.baseStake * cfg.multiplier.pow(st) * 100).roundToLong() / 100.0

    fun refreshStake() {
        Ui.step = step
        Ui.nextStake = stakeFor(step)
    }

    // ------------------------------------------------------------ list handling

    /** Shows the parsed list on the Signals screen without starting anything. */
    fun preview(text: String): String {
        val lines = text.lines().count { it.isNotBlank() }
        val sigs = SignalParser.parse(text)
        val sl = buildSlots(sigs, System.currentTimeMillis())
        Ui.cards.clear()
        sl.forEach { Ui.cards.add(it.item) }
        refreshStake()
        return "${sl.size} signal(s) ready" +
            (if (lines > sigs.size) " - ${lines - sigs.size} unreadable line(s) ignored" else "")
    }

    fun start(text: String): Int {
        stop()
        step = 0
        val today = fmtDay.format(Date())
        if (today != lossDay) { lossDay = today; dailyLoss = 0.0 }
        val lines = text.lines().count { it.isNotBlank() }
        val sigs = SignalParser.parse(text)
        if (lines > sigs.size) log("ignored ${lines - sigs.size} unreadable line(s)")
        slots = buildSlots(sigs, System.currentTimeMillis())
        Ui.cards.clear()
        slots.forEach { Ui.cards.add(it.item) }
        idx = 0
        Ui.running = true
        Ui.statusText = "Waiting"
        refreshStake()
        log("loaded ${slots.size} signal(s)")
        scheduleNext(gen, true)
        return slots.size
    }

    fun stop(reason: String = "Stopped") {
        gen++
        h.removeCallbacksAndMessages(null)
        busy = false
        waiting = null
        Ui.running = false
        Ui.statusText = reason
        Ui.nextAt = 0L
        Ui.nextText = ""
    }

    private fun buildSlots(sigs: List<Signal>, now: Long): List<Slot> {
        val out = ArrayList<Slot>()
        var dayOffset = 0
        var prev = Long.MIN_VALUE
        for (s in sigs) {
            val hr = s.hour
            val mn = s.minute
            val t: Long
            if (hr == null || mn == null) {
                t = if (prev == Long.MIN_VALUE) (now / 60_000 + 1) * 60_000 else prev + 60_000
            } else {
                val cal = Calendar.getInstance()
                cal.timeInMillis = now
                cal.add(Calendar.DAY_OF_YEAR, dayOffset)
                cal.set(Calendar.HOUR_OF_DAY, hr)
                cal.set(Calendar.MINUTE, mn)
                cal.set(Calendar.SECOND, s.second)
                cal.set(Calendar.MILLISECOND, 0)
                var tt = cal.timeInMillis
                if (tt < prev) {            // list crossed midnight
                    dayOffset++
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                    tt = cal.timeInMillis
                }
                t = tt
            }
            prev = t
            val label = if (s.second != 0) fmtHms.format(Date(t)) else fmtHm.format(Date(t))
            out.add(Slot(s, t, SigItem(out.size, t, label, s.asset, s.dir)))
        }
        return out
    }

    // ------------------------------------------------------------ scheduling

    private fun scheduleNext(g: Int, check: Boolean) {
        if (g != gen) return
        val now = System.currentTimeMillis()
        var expired = 0
        while (idx < slots.size && slots[idx].at + cfg.maxLateMs < now) {
            slots[idx].item.status = "skipped"
            slots[idx].item.note = "time had passed"
            idx++
            expired++
        }
        if (expired > 0) log("skipped $expired expired signal(s)")
        if (idx >= slots.size) {
            Ui.nextAt = 0L
            Ui.nextText = ""
            if (check) checkDone()
            return
        }
        val slot = slots[idx]
        Ui.nextAt = slot.at
        Ui.nextText = slot.item.timeLabel + " " + slot.s.dir.uppercase()
        val delay = (slot.at - now - cfg.latencyMs).coerceAtLeast(0)
        h.postDelayed({ fire(slot, g) }, delay)
    }

    private fun checkDone() {
        if (Ui.running && idx >= slots.size && !busy && waiting == null) {
            Ui.running = false
            Ui.statusText = "Finished"
            Ui.nextAt = 0L
            Ui.nextText = ""
            log("all signals done")
            onFinished?.invoke()
        }
    }

    private fun fire(slot: Slot, g: Int) {
        if (g != gen) return
        idx++
        scheduleNext(g, false)               // arm the next signal first
        if (System.currentTimeMillis() - slot.at > cfg.maxLateMs) {
            slot.item.status = "skipped"
            slot.item.note = "missed the candle"
            log("skip (late): ${slot.s.asset} ${slot.s.dir}")
            checkDone()
            return
        }
        if (busy) {
            val old = waiting
            if (old != null) { old.item.status = "skipped"; old.item.note = "replaced by newer signal" }
            waiting = slot
            slot.item.status = "waiting"
            slot.item.note = "waiting for previous result"
            return
        }
        trade(slot, g)
        checkDone()
    }

    private fun finish(g: Int) {
        busy = false
        Ui.statusText = "Waiting"
        val w = waiting
        waiting = null
        if (w != null && g == gen) {
            if (System.currentTimeMillis() - w.at <= cfg.maxLateMs) {
                trade(w, g)
            } else {
                w.item.status = "skipped"
                w.item.note = "too late after result"
                log("skip (late after result): ${w.s.asset} ${w.s.dir}")
                checkDone()
            }
        } else {
            checkDone()
        }
    }

    private fun fail(slot: Slot, reason: String) {
        log(reason)
        slot.item.status = "skipped"
        slot.item.note = reason
        busy = false
        val w = waiting
        if (w != null) { w.item.status = "skipped"; w.item.note = "previous trade failed" }
        waiting = null
        Ui.statusText = "Waiting"
        checkDone()
    }

    // ------------------------------------------------------------ trading

    private fun trade(slot: Slot, g: Int) {
        if (g != gen) return
        busy = true
        Ui.statusText = "Trading"
        val s = slot.s
        if (dailyLoss >= cfg.dailyLossLimit) {
            slot.item.status = "skipped"
            slot.item.note = "daily loss limit"
            log("daily loss limit reached - stopped")
            stop("Loss limit hit")
            return
        }
        val stepNow = step
        val stake = stakeFor(stepNow)
        slot.item.status = "live"
        slot.item.note = "stake " + money(stake)
        web.evaluateJavascript("window.__ov.isDemo()") { r ->
            if (g != gen) return@evaluateJavascript
            val demo = r?.contains("true") == true
            if (!demo && !cfg.allowReal) {
                fail(slot, "not on demo account and REAL is not allowed")
                return@evaluateJavascript
            }
            web.evaluateJavascript("window.__ov.balance()") { b0 ->
                if (g != gen) return@evaluateJavascript
                val before = num(b0)
                if (before == null) {
                    fail(slot, "cannot read balance")
                    return@evaluateJavascript
                }
                web.evaluateJavascript("window.__ov.expiry()") { e0 ->
                    if (g != gen) return@evaluateJavascript
                    val info = e0?.trim('"')
                    val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                    if (info == null || secs == null) {
                        fail(slot, "cannot read expiry box")
                        return@evaluateJavascript
                    }
                    val clock = info[0] == 'c'
                    if (!clock && secs.toInt() != s.expirySec) {
                        fail(slot, "timer is ${secs.toInt()}s, signal needs ${s.expirySec}s")
                        return@evaluateJavascript
                    }
                    checkAsset(s.asset, g) { assetOk ->
                        if (!assetOk) {
                            fail(slot, "page is not on " + prettyAsset(s.asset))
                            return@checkAsset
                        }
                        ensureAmount(stake, g) { okAmt ->
                            if (okAmt) {
                                placeTrades(slot, g, 1, clock, stake, stepNow, before)
                                return@ensureAmount
                            }
                            // amount box can't be changed: build the stake from base-stake trades
                            val n = (stake / cfg.baseStake).roundToInt()
                            if (n < 1 || n > cfg.maxSplit) {
                                fail(slot, "cannot set amount, $n split trades is over the limit")
                                return@ensureAmount
                            }
                            web.evaluateJavascript("window.__ov.amountOk(${cfg.baseStake})") { r2 ->
                                if (g != gen) return@evaluateJavascript
                                if (r2?.contains("true") != true) {
                                    fail(slot, "amount box is not at base stake, cannot split")
                                    return@evaluateJavascript
                                }
                                log("amount locked - placing $n x ${cfg.baseStake} instead of $stake")
                                placeTrades(slot, g, n, clock, stake, stepNow, before)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun checkAsset(asset: String, g: Int, done: (Boolean) -> Unit) {
        val pair = pairText(asset)
        if (pair == null) { done(true); return }       // not a plain pair: cannot verify
        web.evaluateJavascript("window.__ov.hasText('$pair')") { r ->
            if (g != gen) return@evaluateJavascript
            done(r?.contains("true") == true)
        }
    }

    private fun placeTrades(
        slot: Slot, g: Int, n: Int, clock: Boolean,
        stake: Double, stepNow: Int, before: Double
    ) {
        val s = slot.s
        var wanted = n
        var placed = 0
        var lastLeft = -1.0

        fun next() {
            if (g != gen) return
            if (placed >= wanted) {
                log("TRADE ${s.dir.uppercase()} ${s.asset} stake=${money(stake)}" +
                    (if (placed > 1) " as $placed x ${money(cfg.baseStake)}" else "") +
                    (if (stepNow > 0) " (MTG$stepNow)" else "") +
                    (if (clock) " ends in ${money(lastLeft)}s" else ""))
                slot.item.note = "stake " + money(stake) + (if (stepNow > 0) " - MTG$stepNow" else "")
                h.postDelayed({ settle(slot, before, stake, stepNow, g, 0) }, (lastLeft * 1000).toLong() + cfg.graceMs)
                return
            }
            clickTrade(s, g, 0) { left ->
                if (left < 0) {
                    if (placed == 0) {
                        fail(slot, "trade click failed")
                        return@clickTrade
                    }
                    log("only $placed of $n trades placed")
                    wanted = placed
                } else {
                    placed++
                    lastLeft = left
                }
                if (placed < wanted) h.postDelayed({ next() }, 250) else next()
            }
        }
        next()
    }

    private fun clickTrade(s: Signal, g: Int, tries: Int, done: (Double) -> Unit) {
        web.evaluateJavascript("window.__ov.click('${s.dir}')") { r ->
            if (g != gen) return@evaluateJavascript
            val v = num(r) ?: -1.0
            if (v <= -1.5 && tries < 6) {
                h.postDelayed({ clickTrade(s, g, tries + 1, done) }, 200)
            } else {
                done(v)
            }
        }
    }

    private fun ensureAmount(stake: Double, g: Int, done: (Boolean) -> Unit) {
        web.evaluateJavascript("window.__ov.amountOk($stake)") { r ->
            if (g != gen) return@evaluateJavascript
            if (r?.contains("true") == true) { done(true); return@evaluateJavascript }
            web.evaluateJavascript("window.__ov.setAmount($stake)") { m ->
                if (g != gen) return@evaluateJavascript
                if (m == null || m.contains("none") || m.contains("noblock")) {
                    done(false)
                    return@evaluateJavascript
                }
                h.postDelayed({
                    if (g == gen) {
                        web.evaluateJavascript("window.__ov.amountOk($stake)") { r2 ->
                            if (g == gen) done(r2?.contains("true") == true)
                        }
                    }
                }, 350)
            }
        }
    }

    private fun record(slot: Slot, result: String, pnl: Double, stake: Double, stepNow: Int, after: Double) {
        slot.item.status = when (result) { "WIN" -> "won"; "LOSS" -> "lost"; else -> "draw" }
        slot.item.note = (if (pnl >= 0) "+" else "-") + money(abs(pnl)) + (if (stepNow > 0) " - MTG$stepNow" else "")
        Ui.history.add(HistoryItem(slot.item.timeLabel, slot.s.asset, slot.s.dir, stake, stepNow, result, pnl))
        if (result == "WIN") Ui.wins++ else if (result == "LOSS") Ui.losses++
        Ui.pnl += pnl
        Ui.balance = after
    }

    private fun settle(slot: Slot, before: Double, stake: Double, stepNow: Int, g: Int, attempt: Int) {
        if (g != gen) return
        web.evaluateJavascript("window.__ov.balance()") { b1 ->
            if (g != gen) return@evaluateJavascript
            val after = num(b1)
            if (after == null) {
                fail(slot, "cannot read balance after trade - stopped")
                return@evaluateJavascript
            }
            val eps = 0.005
            if (after > before + eps) {
                step = 0
                record(slot, "WIN", after - before, stake, stepNow, after)
                refreshStake()
                log("WIN +${money(after - before)} -> next stake = base")
                finish(g)
                return@evaluateJavascript
            }
            if (attempt == 0) {          // balance can lag: check once more before calling it
                h.postDelayed({ settle(slot, before, stake, stepNow, g, 1) }, 500)
                return@evaluateJavascript
            }
            if (abs(after - before) <= eps) {
                record(slot, "DRAW", 0.0, stake, stepNow, after)
                log("DRAW - next stake unchanged")
            } else {
                val lost = before - after
                dailyLoss += lost
                record(slot, "LOSS", -lost, stake, stepNow, after)
                if (step < cfg.maxSteps) {
                    step++
                    log("LOSS -${money(lost)} -> next signal MTG$step stake=${money(stakeFor(step))}")
                } else {
                    step = 0
                    log("LOSS -${money(lost)}, MTG limit reached -> next stake = base")
                }
            }
            refreshStake()
            finish(g)
        }
    }

    // ------------------------------------------------------------ pre-flight

    fun preflight(done: (List<PreCheck>) -> Unit) {
        val out = ArrayList<PreCheck>()
        web.evaluateJavascript("window.__ov ? window.__ov.isDemo() : null") { r0 ->
            if (r0 == null || r0 == "null") {
                out.add(PreCheck("Broker page ready", false, "page still loading - wait and retry"))
                done(out)
                return@evaluateJavascript
            }
            val demo = r0.contains("true")
            out.add(PreCheck(
                "Account", demo || cfg.allowReal,
                if (demo) "Demo account active" else if (cfg.allowReal) "REAL account (allowed in settings)" else "Switch the broker to the DEMO account"
            ))
            web.evaluateJavascript("window.__ov.balance()") { b0 ->
                val bal = num(b0)
                if (bal != null) Ui.balance = bal
                out.add(PreCheck("Balance readable", bal != null, if (bal != null) money(bal) else "cannot read balance"))
                web.evaluateJavascript("window.__ov.expiry()") { e0 ->
                    val info = e0?.trim('"')
                    val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                    if (info == null || secs == null) {
                        out.add(PreCheck("Expiry", false, "cannot read expiry box"))
                    } else if (info[0] == 'c') {
                        out.add(PreCheck("Expiry", true, "Clock mode, ends in ${secs.toInt()}s"))
                    } else {
                        out.add(PreCheck("Expiry", secs.toInt() == 60, "Timer ${secs.toInt()}s - clock mode (+M1) is recommended"))
                    }
                    web.evaluateJavascript("window.__ov.buttons()") { b2 ->
                        val btn = b2?.contains("true") == true
                        out.add(PreCheck("BUY / SELL buttons", btn, if (btn) "Found" else "Open the trading screen"))
                        web.evaluateJavascript("window.__ov.amount()") { a0 ->
                            val amt = num(a0)
                            val ok = amt != null && abs(amt - cfg.baseStake) < 0.001
                            out.add(PreCheck("Amount box", ok,
                                if (amt == null) "cannot read amount" else "Shows ${money(amt)}, base stake is ${money(cfg.baseStake)}"))
                            val first = Ui.cards.firstOrNull()?.asset
                            val pair = if (first != null) pairText(first) else null
                            if (pair == null) {
                                out.add(PreCheck("Asset", true, "Not verified (no plain pair in list)"))
                                done(out)
                            } else {
                                web.evaluateJavascript("window.__ov.hasText('$pair')") { t0 ->
                                    val ok2 = t0?.contains("true") == true
                                    out.add(PreCheck("Asset $pair", ok2, if (ok2) "Selected on page" else "Select $pair on the page"))
                                    done(out)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun num(r: String?): Double? = r?.trim('"')?.toDoubleOrNull()
}
