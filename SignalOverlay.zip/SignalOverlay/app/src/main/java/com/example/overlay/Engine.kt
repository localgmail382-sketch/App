package com.example.overlay

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Runs the pasted signal list on its own clock and reports everything to [Ui].
 *
 * Martingale (signal-to-signal): each signal is traded with its OWN asset and
 * direction. Stake = base * multiplier^step. LOSS -> step+1 for the next signal
 * (up to maxSteps), WIN -> step 0, DRAW or UNKNOWN -> unchanged.
 * Fail-closed: the app only trades when account type, asset, expiry, amount and
 * balance are all verified, and every entry must be confirmed by the balance.
 */
class Engine(
    private val web: WebView,
    private val cfg: Config,
    private val log: (String) -> Unit
) {
    private class Slot(val s: Signal, val at: Long, val item: SigItem)
    private class LastRec(val item: SigItem, val hist: HistoryItem, val after: Double, val stake: Double)

    var onFinished: (() -> Unit)? = null
    var onHistoryChanged: (() -> Unit)? = null

    private val h = Handler(Looper.getMainLooper())
    private var slots = listOf<Slot>()
    private var idx = 0
    private var busy = false
    private val waitQ = ArrayDeque<Slot>()
    private var step = 0
    private var gen = 0
    private var lastRec: LastRec? = null
    private val evOpen = ArrayList<JSONObject>()
    private val evFail = ArrayList<JSONObject>()
    private val evClose = HashMap<String, JSONObject>()
    private val fmtHm = SimpleDateFormat("HH:mm", Locale.US)
    private val fmtHms = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val fmtDay = SimpleDateFormat("yyyyMMdd", Locale.US)

    private fun today() = fmtDay.format(Date())

    private fun stakeFor(st: Int): Double {
        val v = cfg.baseStake * cfg.multiplier.pow(st)
        return if (v.isFinite()) (v * 100).roundToLong() / 100.0 else Double.NaN
    }

    /** Net loss today (wins offset losses), rebuilt from the saved ledger so a restart cannot reset it. */
    private fun dailyLossNow(): Double {
        val t = today()
        var net = 0.0
        for (hi in Ui.history) if (hi.day == t) net += hi.pnl
        return if (net < 0) -net else 0.0
    }

    fun refreshStake() {
        Ui.step = step
        val s = stakeFor(step)
        Ui.nextStake = if (s.isNaN()) cfg.baseStake else s
        Ui.dailyLoss = dailyLossNow()
    }

    fun resetStats() {
        Ui.history.clear()
        Ui.wins = 0; Ui.losses = 0; Ui.draws = 0; Ui.pnl = 0.0
        step = 0
        lastRec = null
        refreshStake()
        onHistoryChanged?.invoke()
    }

    // ------------------------------------------------------------ list handling

    /** Shows the parsed list on the Signals screen without starting anything. */
    fun preview(text: String): String {
        val res = SignalParser.parseAll(text)
        val sl = buildSlots(res.signals, System.currentTimeMillis())
        Ui.cards.clear()
        sl.forEach { Ui.cards.add(it.item) }
        Ui.parseErrors.clear()
        Ui.parseErrors.addAll(res.errors)
        refreshStake()
        return "${sl.size} signal(s) ready" +
            (if (res.errors.isNotEmpty()) " - ${res.errors.size} invalid line(s)" else "")
    }

    fun start(text: String): Int {
        stop()
        step = 0
        lastRec = null
        evOpen.clear(); evFail.clear(); evClose.clear()
        val res = SignalParser.parseAll(text)
        if (res.errors.isNotEmpty()) log("${res.errors.size} invalid line(s) ignored: " + res.errors.first())
        slots = buildSlots(res.signals, System.currentTimeMillis())
        Ui.cards.clear()
        slots.forEach { Ui.cards.add(it.item) }
        Ui.parseErrors.clear()
        Ui.parseErrors.addAll(res.errors)
        idx = 0
        Ui.running = true
        Ui.statusText = "Waiting"
        refreshStake()
        log("loaded ${slots.size} signal(s)")
        scheduleNext(gen, true)
        return slots.size
    }

    fun stop(reason: String = "Stopped") {
        gen++
        h.removeCallbacksAndMessages(null)
        busy = false
        waitQ.clear()
        for (c in Ui.cards) {
            if (c.status == "pending" || c.status == "waiting") {
                c.status = "skipped"; c.note = "run stopped"
            } else if (c.status == "live") {
                c.status = "unknown"; c.note = "stopped while trade open - check broker"
            }
        }
        Ui.running = false
        Ui.statusText = reason
        Ui.nextAt = 0L
        Ui.nextText = ""
    }

    private fun buildSlots(sigs: List<Signal>, now: Long): List<Slot> {
        val out = ArrayList<Slot>()
        var dayOffset = 0
        var prev = Long.MIN_VALUE
        for (s in sigs) {
            val hr = s.hour
            val mn = s.minute
            val t: Long
            if (hr == null || mn == null) {
                t = if (prev == Long.MIN_VALUE) (now / 60_000 + 1) * 60_000 else prev + 60_000
            } else {
                val cal = Calendar.getInstance()
                cal.timeInMillis = now
                cal.add(Calendar.DAY_OF_YEAR, dayOffset)
                cal.set(Calendar.HOUR_OF_DAY, hr)
                cal.set(Calendar.MINUTE, mn)
                cal.set(Calendar.SECOND, s.second)
                cal.set(Calendar.MILLISECOND, 0)
                var tt = cal.timeInMillis
                if (tt < prev) {            // list crossed midnight
                    dayOffset++
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                    tt = cal.timeInMillis
                }
                t = tt
            }
            prev = t
            val label = if (s.second != 0) fmtHms.format(Date(t)) else fmtHm.format(Date(t))
            out.add(Slot(s, t, SigItem(out.size, t, label, s.asset, s.dir)))
        }
        return out
    }

    // ------------------------------------------------------------ scheduling

    private fun scheduleNext(g: Int, check: Boolean) {
        if (g != gen) return
        val now = System.currentTimeMillis()
        var expired = 0
        while (idx < slots.size && slots[idx].at + cfg.maxLateMs < now) {
            slots[idx].item.status = "skipped"
            slots[idx].item.note = "time had passed"
            idx++
            expired++
        }
        if (expired > 0) log("skipped $expired expired signal(s)")
        if (idx >= slots.size) {
            Ui.nextAt = 0L
            Ui.nextText = ""
            if (check) checkDone()
            return
        }
        val slot = slots[idx]
        Ui.nextAt = slot.at
        Ui.nextText = slot.item.timeLabel + " " + slot.s.dir.uppercase()
        val delay = (slot.at - now - cfg.latencyMs).coerceAtLeast(0)
        h.postDelayed({ fire(slot, g) }, delay)
    }

    private fun checkDone() {
        if (Ui.running && idx >= slots.size && !busy && waitQ.isEmpty()) {
            Ui.running = false
            Ui.statusText = "Finished"
            Ui.nextAt = 0L
            Ui.nextText = ""
            log("all signals done")
            onFinished?.invoke()
        }
    }

    private fun fire(slot: Slot, g: Int) {
        if (g != gen) return
        idx++
        scheduleNext(g, false)               // arm the next signal first
        if (System.currentTimeMillis() - slot.at > cfg.maxLateMs) {
            slot.item.status = "skipped"
            slot.item.note = "missed the candle"
            log("skip (late): ${slot.s.asset} ${slot.s.dir}")
            checkDone()
            return
        }
        if (busy) {                           // every signal is kept in order, none is replaced
            waitQ.addLast(slot)
            slot.item.status = "waiting"
            slot.item.note = "waiting for previous result"
            return
        }
        trade(slot, g)
        checkDone()
    }

    /** Runs the next queued signal if it is still fresh, otherwise marks it skipped. */
    private fun drain(g: Int) {
        if (g != gen) return
        while (waitQ.isNotEmpty()) {
            val w = waitQ.removeFirst()
            if (System.currentTimeMillis() - w.at <= cfg.maxLateMs) {
                trade(w, g)
                return
            }
            w.item.status = "skipped"
            w.item.note = "too late after previous trade"
            log("skip (too late): ${w.s.asset} ${w.s.dir}")
        }
        checkDone()
    }

    private fun finish(g: Int) {
        busy = false
        Ui.statusText = "Waiting"
        drain(g)
    }

    private fun fail(slot: Slot, reason: String) {
        log(reason)
        slot.item.status = "skipped"
        slot.item.note = reason
        busy = false
        Ui.statusText = "Waiting"
        drain(gen)
    }

    // ------------------------------------------------------------ trading

    /** Reads the balance until two reads 200 ms apart agree, so a late payout cannot skew it. */
    private fun stableBalance(g: Int, tries: Int, last: Double?, done: (Double?) -> Unit) {
        web.evaluateJavascript("window.__ov.balance()") { r ->
            if (g != gen) return@evaluateJavascript
            val v = num(r)
            if (v == null) { done(null); return@evaluateJavascript }
            if ((last != null && abs(v - last) < 0.005) || tries >= 8) { done(v); return@evaluateJavascript }
            h.postDelayed({ stableBalance(g, tries + 1, v, done) }, 200)
        }
    }

    /** A payout that landed after we called a trade a loss: fix the record. */
    private fun applyLateCorrection(before: Double) {
        val r = lastRec ?: return
        lastRec = null
        val late = before - r.after
        if (late <= 0.005) return
        val win = late > r.stake + 0.011
        val draw = abs(late - r.stake) <= 0.011
        if (!win && !draw) return
        val old = r.hist
        val newPnl = if (win) late - r.stake else 0.0
        val res = if (win) "WIN" else "DRAW"
        val i = Ui.history.indexOf(old)
        if (i >= 0) Ui.history[i] = HistoryItem(old.day, old.time, old.asset, old.dir, old.stake, old.step, res, newPnl)
        Ui.losses = maxOf(0, Ui.losses - 1)
        if (win) Ui.wins++ else Ui.draws++
        Ui.pnl += newPnl - old.pnl
        r.item.status = if (win) "won" else "draw"
        r.item.note = "corrected (late payout)"
        step = if (win) 0 else old.step
        refreshStake()
        onHistoryChanged?.invoke()
        log("late payout detected - previous trade corrected to $res")
    }

    private fun trade(slot: Slot, g: Int) {
        if (g != gen) return
        busy = true
        Ui.statusText = "Trading"
        val s = slot.s
        if (dailyLossNow() >= cfg.dailyLossLimit) {
            slot.item.status = "skipped"
            slot.item.note = "daily loss limit"
            log("daily loss limit reached - stopped")
            stop("Loss limit hit")
            return
        }
        val bad = cfg.validate()
        if (bad != null) {
            fail(slot, "settings invalid: $bad")
            return
        }
        slot.item.status = "live"
        slot.item.note = "checking page..."
        web.evaluateJavascript("window.__ov.accountType()") { r ->
            if (g != gen) return@evaluateJavascript
            val acct = r?.trim('"') ?: "unknown"
            if (acct != "demo" && !(acct == "real" && cfg.allowReal)) {
                fail(slot, if (acct == "real") "REAL account and REAL is not allowed" else "cannot verify account type - not trading")
                return@evaluateJavascript
            }
            stableBalance(g, 0, null) { before ->
                if (before == null) {
                    fail(slot, "cannot read balance")
                    return@stableBalance
                }
                applyLateCorrection(before)
                val stepNow = step
                val stake = stakeFor(stepNow)
                if (stake.isNaN() || stake < 1.0) {
                    fail(slot, "invalid stake")
                    return@stableBalance
                }
                slot.item.note = "stake " + money(stake)
                web.evaluateJavascript("window.__ov.expiry()") { e0 ->
                    if (g != gen) return@evaluateJavascript
                    val info = e0?.trim('"')
                    val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                    if (info == null || secs == null) {
                        fail(slot, "cannot read expiry box")
                        return@evaluateJavascript
                    }
                    val clock = info[0] == 'c'
                    if (clock && secs > s.expirySec + 5) {
                        fail(slot, "page expiry is ${secs.toInt()}s, expected about ${s.expirySec}s - set Auto Time Offset to +M1")
                        return@evaluateJavascript
                    }
                    if (!clock && secs.toInt() != s.expirySec) {
                        fail(slot, "timer is ${secs.toInt()}s, signal needs ${s.expirySec}s")
                        return@evaluateJavascript
                    }
                    checkAsset(s.asset, g) { err ->
                        if (err != null) {
                            fail(slot, err)
                            return@checkAsset
                        }
                        ensureAmount(stake, g) { okAmt ->
                            if (okAmt) {
                                startPlacing(slot, g, 1, stake, stepNow, before)
                                return@ensureAmount
                            }
                            // amount box can't be changed: build the stake from base-stake trades
                            val n = (stake / cfg.baseStake).roundToInt()
                            if (n < 1 || n > cfg.maxSplit) {
                                fail(slot, "cannot set amount, $n split trades is over the limit")
                                return@ensureAmount
                            }
                            web.evaluateJavascript("window.__ov.amountOk(${cfg.baseStake})") { r2 ->
                                if (g != gen) return@evaluateJavascript
                                if (r2?.contains("true") != true) {
                                    fail(slot, "amount box is not at base stake, cannot split")
                                    return@evaluateJavascript
                                }
                                log("amount locked - placing $n x ${cfg.baseStake} instead of $stake")
                                startPlacing(slot, g, n, stake, stepNow, before)
                            }
                        }
                    }
                }
            }
        }
    }

    /** err = null means the page is on exactly the asset the signal needs. */
    private fun checkAsset(asset: String, g: Int, done: (String?) -> Unit) {
        val pair = pairText(asset)
        if (pair == null) {
            done("cannot verify asset " + prettyAsset(asset) + " (only plain pairs are supported)")
            return
        }
        web.evaluateJavascript("window.__ov.selectedAsset()") { r ->
            if (g != gen) return@evaluateJavascript
            val sel = r?.trim('"')
            if (sel == null || sel == "null" || sel.isEmpty()) {
                done("cannot read the selected asset on the page")
            } else if (!sel.equals(pair, ignoreCase = true)) {
                done("page is on $sel, signal needs $pair")
            } else {
                done(null)
            }
        }
    }

    /** Checks whether the broker's trade-event feed is live, then places the trade(s). */
    private fun startPlacing(slot: Slot, g: Int, n: Int, stake: Double, stepNow: Int, before: Double) {
        web.evaluateJavascript("window.__ovEv && window.__ovEv.alive() ? 'y' : 'n'") { r ->
            if (g != gen) return@evaluateJavascript
            val feed = r?.contains("y") == true
            pump(g) {
                evOpen.clear()          // forget anything older than this trade
                evFail.clear()
                placeTrades(slot, g, n, stake, stepNow, before, feed)
            }
        }
    }

    /** Pulls the trade events captured from the page's websocket into the engine. */
    private fun pump(g: Int, done: () -> Unit) {
        web.evaluateJavascript("window.__ovEv ? window.__ovEv.drain() : '[]'") { raw ->
            if (g != gen) return@evaluateJavascript
            try {
                val v = JSONTokener(raw ?: "null").nextValue()
                val arr = JSONArray(if (v is String) v else "[]")
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val t = e.optLong("t")
                    val p = e.opt("p")
                    when (e.optString("n")) {
                        "successopenOrder" -> if (p is JSONObject) { p.put("_t", t); evOpen.add(p) }
                        "failopenOrder" -> {
                            val o = if (p is JSONObject) p else JSONObject()
                            o.put("_t", t)
                            evFail.add(o)
                        }
                        "successcloseOrder", "updateClosedDeals" -> collectDeals(p)
                    }
                }
            } catch (e: Exception) {
                // unreadable frame: ignore, the balance fallback still covers us
            }
            if (evClose.size > 400) evClose.clear()
            done()
        }
    }

    private fun collectDeals(p: Any?) {
        if (p is JSONArray) {
            for (i in 0 until p.length()) {
                val d = p.optJSONObject(i)
                if (d != null) addClosed(d)
            }
        } else if (p is JSONObject) {
            val arr = p.optJSONArray("deals")
            if (arr != null) collectDeals(arr) else addClosed(p)
        }
    }

    private fun addClosed(d: JSONObject) {
        val id = d.optString("id")
        if (id.isNotEmpty()) evClose[id] = d
    }

    /** Net result of one closed deal, decided from the open and close PRICES (like the broker does). */
    private fun dealNet(d: JSONObject, dir: String): Double? {
        val amount = d.optDouble("amount", Double.NaN)
        val pp = d.optDouble("percentProfit", Double.NaN)
        val op = d.optDouble("openPrice", Double.NaN)
        val cp = d.optDouble("closePrice", Double.NaN)
        if (amount.isNaN() || op.isNaN() || cp.isNaN() || op == 0.0 || cp == 0.0) return null
        val diff = cp - op
        val up = diff > 1e-12
        val down = diff < -1e-12
        val win = if (dir == "call") up else down
        val loss = if (dir == "call") down else up
        if (win) return if (pp.isNaN()) null else amount * pp / 100.0
        if (loss) return -amount
        return 0.0
    }

    private fun describe(o: JSONObject): String {
        val e = o.optString("error").ifEmpty { o.optString("message") }
        return if (e.isNotEmpty()) e else o.toString().take(100)
    }

    /** Entry confirmation from the broker's own "order opened" event. */
    private fun confirmEntryFeed(
        slot: Slot, g: Int, before: Double, expected: Double, placed: Int,
        clickAt: Long, endAt: Long, stepNow: Int, waited: Long
    ) {
        val s = slot.s
        pump(g) {
            val opens = evOpen.filter { it.optLong("_t") >= clickAt - 800 }
            val fails = evFail.filter { it.optLong("_t") >= clickAt - 800 }
            if (opens.size >= placed) {
                val use = opens.take(placed)
                val ids = use.map { it.optString("id") }
                val spent = use.sumOf { it.optDouble("amount", 0.0) }
                val first = use.first()
                val asset = first.optString("asset")
                if (asset.isNotEmpty() && !asset.equals(s.asset, ignoreCase = true)) {
                    log("WARNING: broker opened $asset but the signal said ${s.asset}")
                }
                // broker clock vs phone clock
                val srvOpenMs = first.optLong("openTimestamp") * 1000
                val offset = if (srvOpenMs > 0) srvOpenMs - first.optLong("_t") else 0L
                if (abs(offset) > 2500) log("note: phone clock differs from the broker by ${money(offset / 1000.0)}s - turn on automatic time")
                val closeMs = use.maxOf { it.optLong("closeTimestamp") } * 1000
                val endDev = if (closeMs > 0 && srvOpenMs > 0) closeMs - offset else endAt
                val secsLeft = ((endDev - System.currentTimeMillis()) / 1000.0).coerceAtLeast(0.0)
                log("TRADE ${s.dir.uppercase()} ${s.asset} stake=${money(spent)} confirmed by broker" +
                    (if (placed > 1) " ($placed x ${money(spent / placed)})" else "") +
                    (if (stepNow > 0) " MTG$stepNow" else "") +
                    " ends in ${money(secsLeft)}s")
                if (abs(spent - expected) > 0.011) log("note: broker took ${money(spent)}, expected ${money(expected)}")
                slot.item.note = "stake " + money(spent) + (if (stepNow > 0) " - MTG$stepNow" else "")
                awaitClose(slot, ids, before, spent, stepNow, g, endDev + 20000)
            } else if (fails.isNotEmpty() && opens.isEmpty()) {
                fail(slot, "broker rejected the trade: " + describe(fails.first()))
            } else if (waited >= 4000) {
                log("no order event from the broker - checking the balance instead")
                verifyEntry(slot, g, before, expected, placed, endAt, stepNow, 0)
            } else {
                h.postDelayed({ confirmEntryFeed(slot, g, before, expected, placed, clickAt, endAt, stepNow, waited + 300) }, 300)
            }
        }
    }

    /** Waits for the broker's "order closed" event for every deal, then decides the result from prices. */
    private fun awaitClose(slot: Slot, ids: List<String>, before: Double, spent: Double, stepNow: Int, g: Int, deadline: Long) {
        if (g != gen) return
        pump(g) {
            val deals = ids.mapNotNull { evClose[it] }
            if (deals.size == ids.size) {
                val nets = deals.map { dealNet(it, slot.s.dir) }
                if (nets.any { it == null }) {
                    log("closed deal had no prices - checking the balance instead")
                    settle(slot, before, spent, stepNow, g, 0, null)
                } else {
                    val net = nets.sumOf { it ?: 0.0 }
                    for (d in deals) {
                        log("deal ${d.optString("id").take(6)} open=${d.optDouble("openPrice")} close=${d.optDouble("closePrice")} profit=${d.optDouble("profit")}")
                    }
                    web.evaluateJavascript("window.__ov.balance()") { b -> num(b)?.let { Ui.balance = it } }
                    applyResult(slot, net, spent, stepNow, Ui.balance ?: before, true, g)
                }
            } else if (System.currentTimeMillis() > deadline) {
                log("no close event from the broker - checking the balance instead")
                settle(slot, before, spent, stepNow, g, 0, null)
            } else {
                h.postDelayed({ awaitClose(slot, ids, before, spent, stepNow, g, deadline) }, 400)
            }
        }
    }

    /** One place that turns a net result into win / draw / loss and moves the martingale. */
    private fun applyResult(slot: Slot, net: Double, stake: Double, stepNow: Int, after: Double, viaFeed: Boolean, g: Int) {
        val eps = 0.005
        if (net > eps) {
            step = 0
            record(slot, "WIN", net, stake, stepNow, after)
            log("WIN +${money(net)} -> next stake = base")
        } else if (abs(net) <= eps) {
            record(slot, "DRAW", 0.0, stake, stepNow, after)
            log("DRAW - next stake unchanged")
        } else {
            val lost = -net
            record(slot, "LOSS", net, stake, stepNow, after)
            if (step < cfg.maxSteps) {
                step++
                log("LOSS -${money(lost)} -> next signal MTG$step stake=${money(stakeFor(step))}")
            } else {
                step = 0
                log("LOSS -${money(lost)}, MTG limit reached -> next stake = base")
            }
        }
        if (viaFeed) lastRec = null          // the broker's own result needs no late-payout correction
        refreshStake()
        finish(g)
    }

    private fun placeTrades(slot: Slot, g: Int, n: Int, stake: Double, stepNow: Int, before: Double, useFeed: Boolean) {
        val s = slot.s
        var wanted = n
        var placed = 0
        var endAt = 0L
        val clickAt = System.currentTimeMillis()

        fun next() {
            if (g != gen) return
            if (placed >= wanted) {
                if (useFeed) confirmEntryFeed(slot, g, before, stake, placed, clickAt, endAt, stepNow, 0L)
                else verifyEntry(slot, g, before, stake, placed, endAt, stepNow, 0)
                return
            }
            clickTrade(s, slot.at, g, 0) { left ->
                if (left == -3.0) {
                    fail(slot, "page expiry is too long - set Auto Time Offset to +M1")
                    return@clickTrade
                }
                if (left < 0) {
                    if (placed == 0) {
                        fail(slot, "trade click failed")
                        return@clickTrade
                    }
                    log("only $placed of $n trades placed")
                    wanted = placed
                } else {
                    placed++
                    endAt = System.currentTimeMillis() + (left * 1000).toLong()
                }
                if (placed < wanted) h.postDelayed({ next() }, 250) else next()
            }
        }
        next()
    }

    /** The stake must leave the balance, otherwise the click did not create a trade. */
    private fun verifyEntry(
        slot: Slot, g: Int, before: Double, expected: Double,
        placed: Int, endAt: Long, stepNow: Int, attempt: Int
    ) {
        val s = slot.s
        web.evaluateJavascript("window.__ov.balance()") { r ->
            if (g != gen) return@evaluateJavascript
            val nowBal = num(r)
            val spent = if (nowBal == null) 0.0 else before - nowBal
            if (spent >= cfg.baseStake * 0.5) {
                val secsLeft = ((endAt - System.currentTimeMillis()) / 1000.0).coerceAtLeast(0.0)
                log("TRADE ${s.dir.uppercase()} ${s.asset} stake=${money(spent)} confirmed" +
                    (if (placed > 1) " ($placed x ${money(cfg.baseStake)})" else "") +
                    (if (stepNow > 0) " MTG$stepNow" else "") +
                    " ends in ${money(secsLeft)}s")
                if (abs(spent - expected) > 0.011) log("note: charged ${money(spent)}, expected ${money(expected)}")
                slot.item.note = "stake " + money(spent) + (if (stepNow > 0) " - MTG$stepNow" else "")
                val delay = (endAt + cfg.graceMs - System.currentTimeMillis()).coerceAtLeast(0)
                h.postDelayed({ settle(slot, before, spent, stepNow, g, 0, null) }, delay)
            } else if (attempt < 2) {
                h.postDelayed({ verifyEntry(slot, g, before, expected, placed, endAt, stepNow, attempt + 1) }, 600)
            } else {
                fail(slot, "entry not confirmed - balance did not drop, the trade was probably not placed")
            }
        }
    }

    /** Clicks BUY/SELL. If the clock expiry is about to roll over, waits for it and tries again. */
    private fun clickTrade(s: Signal, slotAt: Long, g: Int, tries: Int, done: (Double) -> Unit) {
        web.evaluateJavascript("window.__ov.click('${s.dir}', ${s.expirySec + 5})") { r ->
            if (g != gen) return@evaluateJavascript
            val v = num(r) ?: -1.0
            if (v > -2.5 && v < -1.5 && tries < 4) {
                web.evaluateJavascript("window.__ov.expiry()") { e ->
                    if (g != gen) return@evaluateJavascript
                    val info = e?.trim('"')
                    val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                    val waitMs = if (secs != null && secs <= 8.0) (secs * 1000).toLong() + 300 else 300L
                    if (System.currentTimeMillis() + waitMs - slotAt > cfg.maxLateMs) {
                        done(-1.0)
                    } else {
                        h.postDelayed({ clickTrade(s, slotAt, g, tries + 1, done) }, waitMs)
                    }
                }
            } else {
                done(v)
            }
        }
    }

    private fun ensureAmount(stake: Double, g: Int, done: (Boolean) -> Unit) {
        web.evaluateJavascript("window.__ov.amountOk($stake)") { r ->
            if (g != gen) return@evaluateJavascript
            if (r?.contains("true") == true) { done(true); return@evaluateJavascript }
            web.evaluateJavascript("window.__ov.setAmount($stake)") { m ->
                if (g != gen) return@evaluateJavascript
                if (m == null || m.contains("none") || m.contains("noblock")) {
                    done(false)
                    return@evaluateJavascript
                }
                h.postDelayed({
                    if (g == gen) {
                        web.evaluateJavascript("window.__ov.amountOk($stake)") { r2 ->
                            if (g == gen) done(r2?.contains("true") == true)
                        }
                    }
                }, 350)
            }
        }
    }

    private fun record(slot: Slot, result: String, pnl: Double, stake: Double, stepNow: Int, after: Double) {
        slot.item.status = when (result) { "WIN" -> "won"; "LOSS" -> "lost"; "DRAW" -> "draw"; else -> "unknown" }
        slot.item.note = when (result) {
            "UNKNOWN" -> "result unclear - check the broker"
            else -> (if (pnl >= 0) "+" else "-") + money(abs(pnl)) + (if (stepNow > 0) " - MTG$stepNow" else "")
        }
        val hi = HistoryItem(today(), slot.item.timeLabel, slot.s.asset, slot.s.dir, stake, stepNow, result, pnl)
        Ui.history.add(hi)
        lastRec = if (result == "LOSS") LastRec(slot.item, hi, after, stake) else null
        when (result) {
            "WIN" -> Ui.wins++
            "LOSS" -> Ui.losses++
            "DRAW" -> Ui.draws++
        }
        Ui.pnl += pnl
        Ui.balance = after
        onHistoryChanged?.invoke()
    }

    /** Waits until the balance stops changing, then decides win / draw / loss from the net change. */
    private fun settle(slot: Slot, before: Double, stake: Double, stepNow: Int, g: Int, round: Int, prev: Double?) {
        if (g != gen) return
        web.evaluateJavascript("window.__ov.balance()") { r ->
            if (g != gen) return@evaluateJavascript
            val after = num(r)
            if (after == null) {
                fail(slot, "cannot read balance after trade - result unknown")
                return@evaluateJavascript
            }
            val eps = 0.005
            val stable = prev != null && abs(after - prev) <= eps
            if (!stable && round < 6) {
                h.postDelayed({ settle(slot, before, stake, stepNow, g, round + 1, after) }, 700)
                return@evaluateJavascript
            }
            if (!stable) {                      // balance never settled: do not guess
                record(slot, "UNKNOWN", 0.0, stake, stepNow, after)
                log("RESULT UNKNOWN - balance kept changing, stake unchanged. Check the broker.")
                refreshStake()
                finish(g)
                return@evaluateJavascript
            }
            applyResult(slot, after - before, stake, stepNow, after, false, g)
        }
    }

    // ------------------------------------------------------------ pre-flight

    fun preflight(done: (List<PreCheck>) -> Unit) {
        val out = ArrayList<PreCheck>()
        val bad = cfg.validate()
        out.add(PreCheck("Settings", bad == null,
            bad ?: "Stake ${money(cfg.baseStake)}, x${cfg.multiplier}, ${cfg.maxSteps} steps"))
        val n = Ui.cards.size
        val perr = Ui.parseErrors.size
        out.add(PreCheck("Signal list", n > 0 && perr == 0,
            if (n == 0) "No signals loaded"
            else if (perr > 0) "$perr invalid line(s): " + Ui.parseErrors.first()
            else "$n signal(s) ready"))

        web.evaluateJavascript("window.__ov ? window.__ov.accountType() : null") { r0 ->
            if (r0 == null || r0 == "null") {
                out.add(PreCheck("Broker page ready", false, "page still loading - wait and retry"))
                done(out)
                return@evaluateJavascript
            }
            val acct = r0.trim('"')
            Ui.accountType = acct
            out.add(PreCheck(
                "Account",
                acct == "demo" || (acct == "real" && cfg.allowReal),
                when (acct) {
                    "demo" -> "Demo account verified"
                    "real" -> if (cfg.allowReal) "REAL account (allowed in settings)" else "REAL account - switch to DEMO or enable REAL in settings"
                    else -> "Cannot verify account type - the app will not trade"
                }
            ))
            web.evaluateJavascript("window.__ov.balance()") { b0 ->
                val bal = num(b0)
                if (bal != null) Ui.balance = bal
                out.add(PreCheck("Balance readable", bal != null, if (bal != null) money(bal) else "cannot read balance"))
                if (bal != null && bad == null) {
                    var worst = 0.0
                    for (i in 0..cfg.maxSteps) worst += cfg.baseStake * cfg.multiplier.pow(i)
                    out.add(PreCheck("Risk budget", worst <= bal,
                        "Worst chain ${money(worst)} vs balance ${money(bal)}"))
                }
                web.evaluateJavascript("window.__ov.payout()") { p0 ->
                    val pay = num(p0)
                    if (pay != null) Ui.payout = pay
                    web.evaluateJavascript("window.__ov.expiry()") { e0 ->
                        val info = e0?.trim('"')
                        val secs = if (info != null && info.length > 1) info.substring(1).toDoubleOrNull() else null
                        if (info == null || secs == null) {
                            out.add(PreCheck("Expiry", false, "cannot read expiry box"))
                        } else if (info[0] == 'c') {
                            out.add(PreCheck("Expiry", secs <= 65,
                                if (secs <= 65) "Clock mode, ends in ${secs.toInt()}s" else "Expiry too long (${secs.toInt()}s) - set Auto Time Offset +M1"))
                        } else {
                            out.add(PreCheck("Expiry", secs.toInt() == 60, "Timer ${secs.toInt()}s - clock mode (+M1) is recommended"))
                        }
                        web.evaluateJavascript("window.__ov.buttons()") { b2 ->
                            val btn = b2?.contains("true") == true
                            out.add(PreCheck("BUY / SELL buttons", btn, if (btn) "Found" else "Open the trading screen"))
                            web.evaluateJavascript("window.__ov.amount()") { a0 ->
                                val amt = num(a0)
                                val ok = amt != null && abs(amt - cfg.baseStake) < 0.001
                                out.add(PreCheck("Amount box", ok,
                                    if (amt == null) "cannot read amount" else "Shows ${money(amt)}, base stake is ${money(cfg.baseStake)}"))
                                val upcoming = Ui.cards.firstOrNull { it.status == "pending" } ?: Ui.cards.firstOrNull()
                                val pair = if (upcoming != null) pairText(upcoming.asset) else null
                                if (upcoming == null) {
                                    out.add(PreCheck("Asset", false, "No signals loaded"))
                                    finishChecks(out, done)
                                } else if (pair == null) {
                                    out.add(PreCheck("Asset", false, "Cannot verify " + prettyAsset(upcoming.asset)))
                                    finishChecks(out, done)
                                } else {
                                    web.evaluateJavascript("window.__ov.selectedAsset()") { t0 ->
                                        val sel = t0?.trim('"')
                                        val okA = sel != null && sel != "null" && sel.equals(pair, ignoreCase = true)
                                        out.add(PreCheck("Asset $pair", okA,
                                            if (okA) "Selected on page"
                                            else if (sel == null || sel == "null" || sel.isEmpty()) "Cannot read the selected asset"
                                            else "Page is on $sel - select $pair"))
                                        finishChecks(out, done)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun finishChecks(out: ArrayList<PreCheck>, done: (List<PreCheck>) -> Unit) {
        web.evaluateJavascript("window.__ovEv && window.__ovEv.alive() ? 'y' : 'n'") { r ->
            val live = r?.contains("y") == true
            out.add(PreCheck("Trade feed", true,
                if (live) "Live - results come from the broker's own events"
                else "Not detected - the balance method will be used. Tap Reload page to enable the feed"))
            done(out)
        }
    }

    private fun num(r: String?): Double? = r?.trim('"')?.toDoubleOrNull()
}
