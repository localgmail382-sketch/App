package com.example.overlay

import android.content.SharedPreferences

data class Signal(
    val asset: String,
    val dir: String,        // "call" or "put"
    val hour: Int?,
    val minute: Int?,
    val second: Int,
    val expirySec: Int
)

class Config {
    var baseStake = 1.0
    var multiplier = 2.0
    var maxSteps = 2            // 2 = MTG1 and MTG2
    var maxSplit = 8            // max number of base-stake trades used to build one bigger stake
    var dailyLossLimit = 30.0
    var allowReal = false       // never saved: must be switched on again every session
    var latencyMs = -100L       // negative = fire this much AFTER the candle opens
    var maxLateMs = 5000L       // skip a signal if missed by more than this
    var graceMs = 800L          // wait after expiry before reading the result

    /** null = settings are usable, otherwise a message for the user. */
    fun validate(): String? {
        if (!baseStake.isFinite() || baseStake < 1.0 || baseStake > 1000.0) return "Base stake must be between 1 and 1000"
        if (!multiplier.isFinite() || multiplier < 1.0 || multiplier > 4.0) return "Multiplier must be between 1 and 4"
        if (maxSteps < 0 || maxSteps > 6) return "MTG steps must be between 0 and 6"
        if (!dailyLossLimit.isFinite() || dailyLossLimit <= 0.0) return "Daily loss stop must be above 0"
        val top = baseStake * Math.pow(multiplier, maxSteps.toDouble())
        if (!top.isFinite() || top > 5000.0) return "Largest stake would be above 5000"
        return null
    }

    fun save(p: SharedPreferences) {
        p.edit()
            .putFloat("base", baseStake.toFloat())
            .putFloat("mult", multiplier.toFloat())
            .putInt("steps", maxSteps)
            .putFloat("loss", dailyLossLimit.toFloat())
            .apply()
    }

    fun load(p: SharedPreferences) {
        baseStake = p.getFloat("base", 1f).toDouble()
        multiplier = p.getFloat("mult", 2f).toDouble()
        maxSteps = p.getInt("steps", 2)
        dailyLossLimit = p.getFloat("loss", 30f).toDouble()
        allowReal = false
        if (validate() != null) {          // damaged or old values: fall back to safe defaults
            baseStake = 1.0; multiplier = 2.0; maxSteps = 2; dailyLossLimit = 30.0
        }
    }
}

class ParseResult(val signals: List<Signal>, val errors: List<String>)

/**
 * One signal per line:  [HH:mm[:ss]] ASSET CALL|PUT [expirySec]
 * No time = next free candle open (one per minute, in order).
 * Every line is validated; problems are reported per line.
 */
object SignalParser {
    private val re = Regex(
        """^(?:(\d{1,2}):(\d{2})(?::(\d{2}))?\s+)?([A-Za-z0-9_/\-]+)\s+(CALL|PUT|BUY|SELL|UP|DOWN)(?:\s+(\d+))?(?:\s+\d+(?:\.\d+)?)?$""",
        RegexOption.IGNORE_CASE
    )

    fun parseAll(text: String, defExpiry: Int = 60): ParseResult {
        val sigs = ArrayList<Signal>()
        val errs = ArrayList<String>()
        text.lines().forEachIndexed { i, raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEachIndexed
            val m = re.matchEntire(line)
            if (m == null) {
                errs.add("line ${i + 1}: not understood")
                return@forEachIndexed
            }
            val g = m.groupValues
            val hr = g[1].toIntOrNull()
            val mn = g[2].toIntOrNull()
            val sc = g[3].toIntOrNull() ?: 0
            val ex = g[6].toIntOrNull() ?: defExpiry
            if (hr != null && (hr > 23 || (mn ?: 0) > 59 || sc > 59)) {
                errs.add("line ${i + 1}: invalid time")
                return@forEachIndexed
            }
            if (ex < 5 || ex > 3600) {
                errs.add("line ${i + 1}: expiry must be 5-3600 seconds")
                return@forEachIndexed
            }
            val d = when (g[5].uppercase()) {
                "CALL", "BUY", "UP" -> "call"
                else -> "put"
            }
            sigs.add(Signal(asset = g[4], dir = d, hour = hr, minute = mn, second = sc, expirySec = ex))
        }
        return ParseResult(sigs, errs)
    }

    fun parse(text: String, defExpiry: Int = 60): List<Signal> = parseAll(text, defExpiry).signals
}
