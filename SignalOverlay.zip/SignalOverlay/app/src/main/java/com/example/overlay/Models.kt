package com.example.overlay

import android.content.SharedPreferences

data class Signal(
    val asset: String,
    val dir: String,        // "call" or "put"
    val hour: Int?,
    val minute: Int?,
    val second: Int,
    val expirySec: Int
)

class Config {
    var baseStake = 1.0
    var multiplier = 2.0
    var maxSteps = 2            // 2 = MTG1 and MTG2
    var maxSplit = 8            // max number of base-stake trades used to build one bigger stake
    var dailyLossLimit = 30.0
    var allowReal = false       // never saved: must be switched on again every session
    var assumeOtc = true        // pairs without "OTC" in the pasted text are treated as OTC
    var timeShiftMin = 0        // minutes added to every pasted signal time (for a channel in another time zone)
    var latencyMs = -100L       // negative = fire this much AFTER the candle opens
    var maxLateMs = 5000L       // skip a signal if missed by more than this
    var graceMs = 800L          // wait after expiry before reading the result

    /** null = settings are usable, otherwise a message for the user. */
    fun validate(): String? {
        if (!baseStake.isFinite() || baseStake < 1.0 || baseStake > 1000.0) return "Base stake must be between 1 and 1000"
        if (!multiplier.isFinite() || multiplier < 1.0 || multiplier > 4.0) return "Multiplier must be between 1 and 4"
        if (maxSteps < 0 || maxSteps > 6) return "MTG steps must be between 0 and 6"
        if (!dailyLossLimit.isFinite() || dailyLossLimit <= 0.0) return "Daily loss stop must be above 0"
        val top = baseStake * Math.pow(multiplier, maxSteps.toDouble())
        if (!top.isFinite() || top > 5000.0) return "Largest stake would be above 5000"
        if (timeShiftMin < -720 || timeShiftMin > 720) return "Time shift must be between -720 and 720 minutes"
        return null
    }

    fun save(p: SharedPreferences) {
        p.edit()
            .putFloat("base", baseStake.toFloat())
            .putFloat("mult", multiplier.toFloat())
            .putInt("steps", maxSteps)
            .putFloat("loss", dailyLossLimit.toFloat())
            .putBoolean("otc", assumeOtc)
            .putInt("shift", timeShiftMin)
            .apply()
    }

    fun load(p: SharedPreferences) {
        baseStake = p.getFloat("base", 1f).toDouble()
        multiplier = p.getFloat("mult", 2f).toDouble()
        maxSteps = p.getInt("steps", 2)
        dailyLossLimit = p.getFloat("loss", 30f).toDouble()
        allowReal = false
        assumeOtc = p.getBoolean("otc", true)
        timeShiftMin = p.getInt("shift", 0)
        if (validate() != null) {          // damaged or old values: fall back to safe defaults
            baseStake = 1.0; multiplier = 2.0; maxSteps = 2; dailyLossLimit = 30.0; timeShiftMin = 0
        }
    }
}

class ParseResult(val signals: List<Signal>, val errors: List<String>, val ignored: Int)

/**
 * Reads signals in almost any layout and turns them into [Signal]s:
 *   16:01 | AUDCAD | ADX | 1M | PUT      USDBDT-OTC 00:46 CALL 1M      4:05 PM AUD/CAD OTC BUY 60s ...
 * Text that is not a signal (titles, links, contacts) is ignored. Real problems are reported per line.
 */
object SignalParser {
    private val timeRe = Regex("""(?<!\d)(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?""")
    private val dirRe = Regex("""(?i)\b(CALL|PUT|BUY|SELL|UP|DOWN|HIGHER|LOWER)\b""")
    private val expUnitRe = Regex("""(?i)\b(\d{1,4})\s*(MINUTES|MINUTE|MINS|MIN|M|SECONDS|SECOND|SECS|SEC|S)\b""")
    private val expMRe = Regex("""(?i)\bM(\d{1,3})\b""")
    private val bareRe = Regex("""\b(\d{1,4})\b""")
    private val otcWordRe = Regex("""(?i)\bOTC\b""")
    private val pairSepRe = Regex("""(?i)\b([A-Z]{3})\s*[/\-]\s*([A-Z]{3})\b""")
    private val pair6Re = Regex("""(?i)\b([A-Z]{6})\b""")
    private val pairSpaceRe = Regex("""(?i)\b([A-Z]{3})\s+([A-Z]{3})\b""")

    private val known = setOf(
        "USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "NZD", "BDT", "INR", "PKR", "TRY", "BRL", "ZAR", "MXN",
        "SGD", "HKD", "CNH", "CNY", "SEK", "NOK", "DKK", "PLN", "HUF", "CZK", "RUB", "THB", "IDR", "MYR", "PHP",
        "KRW", "TWD", "EGP", "NGN", "SAR", "AED", "ILS", "ARS", "COP", "CLP", "PEN", "UAH", "VND", "LBP", "DZD",
        "MAD", "TND", "KES", "QAR", "KWD", "OMR", "JOD", "BHD", "LKR", "NPR", "KZT", "AZN", "GEL", "BTC", "ETH",
        "LTC", "XRP", "BNB", "ADA", "DOT", "SOL", "DOG", "XAU", "XAG", "XPT", "XPD", "BCH", "EOS", "TRX", "MAT",
        "AVA", "LNK", "UNI", "ATO", "XLM", "BTT", "DAS", "ZEC"
    )

    private class Line(val sig: Signal?, val err: String?)

    private fun findPair(text: String): String? {
        for (m in pairSepRe.findAll(text)) return (m.groupValues[1] + m.groupValues[2]).uppercase()
        for (m in pair6Re.findAll(text)) {
            val w = m.groupValues[1].uppercase()
            if (known.contains(w.substring(0, 3)) && known.contains(w.substring(3))) return w
        }
        for (m in pairSpaceRe.findAll(text)) {
            val a = m.groupValues[1].uppercase()
            val b = m.groupValues[2].uppercase()
            if (known.contains(a) && known.contains(b)) return a + b
        }
        return null
    }

    /** null Line = not a signal (ignored). */
    private fun parseLine(raw: String, n: Int, assumeOtc: Boolean, defExpiry: Int): Line? {
        var line = raw.trim().replace('_', ' ').replace('|', ' ').replace(',', ' ').replace(';', ' ')
            .replace('[', ' ').replace(']', ' ').replace('(', ' ').replace(')', ' ')
        if (line.isEmpty()) return null

        // time
        var hr: Int? = null
        var mn: Int? = null
        var sc = 0
        val tm = timeRe.find(line)
        if (tm != null) {
            var h = tm.groupValues[1].toInt()
            mn = tm.groupValues[2].toInt()
            sc = tm.groupValues[3].toIntOrNull() ?: 0
            val ap = tm.groupValues[4].uppercase()
            if (ap.isNotEmpty()) {
                if (h < 1 || h > 12) return Line(null, "line $n: invalid time")
                h = (h % 12) + (if (ap == "PM") 12 else 0)
            }
            if (h > 23 || mn > 59 || sc > 59) return Line(null, "line $n: invalid time")
            hr = h
            line = line.removeRange(tm.range)
        }

        // direction (word or arrow)
        var dir: String? = null
        val dm = dirRe.find(line)
        if (dm != null) {
            dir = when (dm.groupValues[1].uppercase()) {
                "CALL", "BUY", "UP", "HIGHER" -> "call"
                else -> "put"
            }
            line = line.removeRange(dm.range)
        } else if (Regex("[\uD83D\uDFE2\uD83D\uDD3C\u2B06\uD83D\uDCC8]").containsMatchIn(line)) {
            dir = "call"
        } else if (Regex("[\uD83D\uDD34\uD83D\uDD3D\u2B07\uD83D\uDCC9]").containsMatchIn(line)) {
            dir = "put"
        }

        // OTC marker
        val otc = otcWordRe.containsMatchIn(line)
        line = line.replace(otcWordRe, " ")

        // expiry
        var exp: Int? = null
        val um = expUnitRe.find(line)
        if (um != null) {
            val v = um.groupValues[1].toInt()
            exp = if (um.groupValues[2].uppercase().startsWith("M")) v * 60 else v
            line = line.removeRange(um.range)
        } else {
            val mm = expMRe.find(line)
            if (mm != null) {
                exp = mm.groupValues[1].toInt() * 60
                line = line.removeRange(mm.range)
            } else {
                val bm = bareRe.find(line)
                if (bm != null) {
                    val v = bm.groupValues[1].toInt()
                    exp = if (v < 5) v * 60 else v
                    line = line.removeRange(bm.range)
                }
            }
        }

        val pair = findPair(line)
        if (dir == null) {
            // a line that has a time and an asset but no CALL/PUT is a broken signal; anything else is just text
            return if (hr != null && pair != null) Line(null, "line $n: no CALL or PUT found") else null
        }
        if (pair == null) return Line(null, "line $n: asset not recognised")
        val e = exp ?: defExpiry
        if (e < 5 || e > 3600) return Line(null, "line $n: expiry must be 5-3600 seconds")
        val asset = pair + (if (otc || assumeOtc) "_otc" else "")
        return Line(Signal(asset = asset, dir = dir, hour = hr, minute = mn, second = sc, expirySec = e), null)
    }

    fun parseAll(text: String, defExpiry: Int = 60, assumeOtc: Boolean = true): ParseResult {
        val sigs = ArrayList<Signal>()
        val errs = ArrayList<String>()
        var ignored = 0
        text.lines().forEachIndexed { i, raw ->
            if (raw.isBlank()) return@forEachIndexed
            val r = parseLine(raw, i + 1, assumeOtc, defExpiry)
            if (r == null) ignored++
            else if (r.err != null) errs.add(r.err)
            else if (r.sig != null) sigs.add(r.sig)
        }
        return ParseResult(sigs, errs, ignored)
    }

    fun parse(text: String, defExpiry: Int = 60, assumeOtc: Boolean = true): List<Signal> =
        parseAll(text, defExpiry, assumeOtc).signals

    /** The pasted text rewritten as clean lines:  HH:mm ASSET DIRECTION SECONDS */
    fun normalize(text: String, assumeOtc: Boolean = true): String {
        val sb = StringBuilder()
        for (s in parse(text, 60, assumeOtc)) {
            if (s.hour != null && s.minute != null) {
                sb.append(String.format("%02d:%02d", s.hour, s.minute))
                if (s.second != 0) sb.append(String.format(":%02d", s.second))
                sb.append(' ')
            }
            sb.append(s.asset).append(' ').append(s.dir.uppercase()).append(' ').append(s.expirySec).append('\n')
        }
        return sb.toString().trimEnd()
    }
}
