package com.example.overlay

import android.content.SharedPreferences

data class Signal(
    val asset: String,
    val dir: String,        // "call" or "put"
    val hour: Int?,
    val minute: Int?,
    val second: Int,
    val expirySec: Int
)

class Config {
    var baseStake = 1.0
    var multiplier = 2.0
    var maxSplit = 8            // max number of base-stake trades used to build one bigger stake
    var maxSteps = 2            // 2 = MTG1 and MTG2
    var dailyLossLimit = 30.0
    var allowReal = false
    var latencyMs = -100L       // negative = fire this much AFTER the candle opens
    var maxLateMs = 3000L       // skip a signal if missed by more than this
    var graceMs = 300L          // wait after expiry before reading the result

    fun save(p: SharedPreferences) {
        p.edit()
            .putFloat("base", baseStake.toFloat())
            .putFloat("mult", multiplier.toFloat())
            .putInt("steps", maxSteps)
            .putFloat("loss", dailyLossLimit.toFloat())
            .putBoolean("real", allowReal)
            .apply()
    }

    fun load(p: SharedPreferences) {
        baseStake = p.getFloat("base", 1f).toDouble()
        multiplier = p.getFloat("mult", 2f).toDouble()
        maxSteps = p.getInt("steps", 2)
        dailyLossLimit = p.getFloat("loss", 30f).toDouble()
        allowReal = p.getBoolean("real", false)
    }
}

/**
 * One signal per line:
 *   [HH:mm[:ss]] ASSET CALL|PUT [expirySec]
 * No time = next free candle open (one per minute, in order).
 */
object SignalParser {
    private val re = Regex(
        """^(?:(\d{1,2}):(\d{2})(?::(\d{2}))?\s+)?([A-Za-z0-9_/\-]+)\s+(CALL|PUT|BUY|SELL|UP|DOWN)(?:\s+(\d+))?(?:\s+\d+(?:\.\d+)?)?$""",
        RegexOption.IGNORE_CASE
    )

    fun parse(text: String, defExpiry: Int = 60): List<Signal> =
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { line ->
            val m = re.matchEntire(line) ?: return@mapNotNull null
            val g = m.groupValues
            val d = when (g[5].uppercase()) {
                "CALL", "BUY", "UP" -> "call"
                else -> "put"
            }
            Signal(
                asset = g[4],
                dir = d,
                hour = g[1].toIntOrNull(),
                minute = g[2].toIntOrNull(),
                second = g[3].toIntOrNull() ?: 0,
                expirySec = g[6].toIntOrNull() ?: defExpiry
            )
        }
}
